package com.example.guadeloupedex

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions

data class Animal(val id:Int,val name:String,val scientific:String,val icon:String,val category:String,val rarity:String)
val animals=listOf(
    Animal(1, "Raton laveur de Guadeloupe", "Procyon lotor", "🦝", "Mammifères", "Rare"),
    Animal(2, "Iguane des Petites-Antilles", "Iguana delicatissima", "🦎", "Reptiles", "Très rare"),
    Animal(3, "Iguane vert", "Iguana iguana", "🦎", "Reptiles", "Commun"),
    Animal(4, "Anolis de Guadeloupe", "Anolis marmoratus", "🦎", "Reptiles", "Commun"),
    Animal(5, "Mabouya à pattes jaunes", "Hemidactylus mabouia", "🦎", "Reptiles", "Commun"),
    Animal(6, "Técadactyle", "Thecadactylus rapicauda", "🦎", "Reptiles", "Commun"),
    Animal(7, "Typhlops de Guadeloupe", "Typhlops guadeloupensis", "🐍", "Reptiles", "Très rare"),
    Animal(8, "Couresse de Guadeloupe", "Alsophis antillensis", "🐍", "Reptiles", "Très rare"),
    Animal(9, "Couresse des Saintes", "Alsophis sanctonum", "🐍", "Reptiles", "Très rare"),
    Animal(10, "Hylode de Pinchon", "Eleutherodactylus pinchoni", "🐸", "Amphibiens", "Rare"),
    Animal(11, "Hylode de Barlagne", "Eleutherodactylus barlagnei", "🐸", "Amphibiens", "Rare"),
    Animal(12, "Hylode de la Martinique", "Eleutherodactylus martinicensis", "🐸", "Amphibiens", "Commun"),
    Animal(13, "Hylode de Johnstone", "Eleutherodactylus johnstonei", "🐸", "Amphibiens", "Commun"),
    Animal(14, "Tortue verte", "Chelonia mydas", "🐢", "Tortues marines", "Rare"),
    Animal(15, "Tortue imbriquée", "Eretmochelys imbricata", "🐢", "Tortues marines", "Rare"),
    Animal(16, "Tortue luth", "Dermochelys coriacea", "🐢", "Tortues marines", "Très rare"),
    Animal(17, "Tortue caouanne", "Caretta caretta", "🐢", "Tortues marines", "Occasionnel"),
    Animal(18, "Tortue olivâtre", "Lepidochelys olivacea", "🐢", "Tortues marines", "Occasionnel"),
    Animal(19, "Sérotine de Guadeloupe", "Eptesicus guadeloupensis", "🦇", "Chauves-souris", "Très rare"),
    Animal(20, "Fer-de-lance commun", "Artibeus jamaicensis", "🦇", "Chauves-souris", "Commun"),
    Animal(21, "Sturnire de la Guadeloupe", "Sturnira angeli", "🦇", "Chauves-souris", "Rare"),
    Animal(22, "Ardops des Petites-Antilles", "Ardops nichollsi", "🦇", "Chauves-souris", "Rare"),
    Animal(23, "Monophylle des Petites-Antilles", "Monophyllus plethodon", "🦇", "Chauves-souris", "Rare"),
    Animal(24, "Noctilion pêcheur", "Noctilio leporinus", "🦇", "Chauves-souris", "Rare"),
    Animal(25, "Pteronote de Davy", "Pteronotus davyi", "🦇", "Chauves-souris", "Rare"),
    Animal(26, "Molosse commun", "Molossus molossus", "🦇", "Chauves-souris", "Commun"),
    Animal(27, "Tadaride du Brésil", "Tadarida brasiliensis", "🦇", "Chauves-souris", "Commun"),
    Animal(28, "Dauphin tacheté pantropical", "Stenella attenuata", "🐬", "Mammifères marins", "Commun"),
    Animal(29, "Grand dauphin", "Tursiops truncatus", "🐬", "Mammifères marins", "Commun"),
    Animal(30, "Dauphin commun", "Delphinus delphis", "🐬", "Mammifères marins", "Occasionnel"),
    Animal(31, "Dauphin de Fraser", "Lagenodelphis hosei", "🐬", "Mammifères marins", "Rare"),
    Animal(32, "Dauphin à long bec", "Stenella longirostris", "🐬", "Mammifères marins", "Rare"),
    Animal(33, "Dauphin tacheté de l’Atlantique", "Stenella frontalis", "🐬", "Mammifères marins", "Occasionnel"),
    Animal(34, "Globicéphale tropical", "Globicephala macrorhynchus", "🐋", "Mammifères marins", "Commun"),
    Animal(35, "Grand cachalot", "Physeter macrocephalus", "🐋", "Mammifères marins", "Rare"),
    Animal(36, "Cachalot nain", "Kogia sima", "🐋", "Mammifères marins", "Très rare"),
    Animal(37, "Baleine à bosse", "Megaptera novaeangliae", "🐋", "Mammifères marins", "Rare"),
    Animal(38, "Orque naine", "Feresa attenuata", "🐋", "Mammifères marins", "Très rare"),
    Animal(39, "Pseudorque", "Pseudorca crassidens", "🐋", "Mammifères marins", "Très rare"),
    Animal(40, "Pic de Guadeloupe", "Melanerpes herminieri", "🐦", "Oiseaux", "Rare"),
    Animal(41, "Crécerelle d’Amérique", "Falco sparverius", "🦅", "Oiseaux", "Commun"),
    Animal(42, "Frégate superbe", "Fregata magnificens", "🦅", "Oiseaux", "Commun"),
    Animal(43, "Pélican brun", "Pelecanus occidentalis", "🐦", "Oiseaux", "Commun"),
    Animal(44, "Fou brun", "Sula leucogaster", "🐦", "Oiseaux", "Occasionnel"),
    Animal(45, "Paille-en-queue à bec rouge", "Phaethon aethereus", "🐦", "Oiseaux", "Rare"),
    Animal(46, "Héron garde-bœufs", "Bubulcus ibis", "🐦", "Oiseaux", "Commun"),
    Animal(47, "Héron vert", "Butorides virescens", "🐦", "Oiseaux", "Commun"),
    Animal(48, "Grande aigrette", "Ardea alba", "🐦", "Oiseaux", "Commun"),
    Animal(49, "Aigrette neigeuse", "Egretta thula", "🐦", "Oiseaux", "Commun"),
    Animal(50, "Aigrette bleue", "Egretta caerulea", "🐦", "Oiseaux", "Commun"),
    Animal(51, "Paruline jaune", "Setophaga petechia", "🐦", "Oiseaux", "Commun"),
    Animal(52, "Paruline caféiette", "Setophaga plumbea", "🐦", "Oiseaux", "Rare"),
    Animal(53, "Sporophile rouge-gorge", "Loxigilla noctis", "🐦", "Oiseaux", "Commun"),
    Animal(54, "Sucrier à ventre jaune", "Coereba flaveola", "🐦", "Oiseaux", "Très commun"),
    Animal(55, "Trembleur brun", "Cinclocerthia ruficauda", "🐦", "Oiseaux", "Commun"),
    Animal(56, "Merle à lunettes", "Turdus nudigenis", "🐦", "Oiseaux", "Commun"),
    Animal(57, "Quiscale merle", "Quiscalus lugubris", "🐦", "Oiseaux", "Commun"),
    Animal(58, "Moqueur grivotte", "Margarops fuscatus", "🐦", "Oiseaux", "Commun"),
    Animal(59, "Colibri madère", "Eulampis jugularis", "🐦", "Oiseaux", "Commun"),
    Animal(60, "Colibri huppé", "Orthorhyncus cristatus", "🐦", "Oiseaux", "Commun"),
    Animal(61, "Colibri falle-vert", "Eulampis holosericeus", "🐦", "Oiseaux", "Commun"),
    Animal(62, "Tourterelle à queue carrée", "Zenaida aurita", "🐦", "Oiseaux", "Commun"),
    Animal(63, "Tourterelle triste", "Zenaida macroura", "🐦", "Oiseaux", "Commun"),
    Animal(64, "Colombe à queue noire", "Columbina passerina", "🐦", "Oiseaux", "Commun"),
    Animal(65, "Moucherolle gobe-mouches", "Contopus latirostris", "🐦", "Oiseaux", "Rare"),
    Animal(66, "Balbuzard pêcheur", "Pandion haliaetus", "🦅", "Oiseaux", "Occasionnel"),
    Animal(67, "Hirondelle à ventre blanc", "Progne dominicensis", "🐦", "Oiseaux", "Commun"),
    Animal(68, "Martinet ramoneur", "Chaetura pelagica", "🐦", "Oiseaux", "Occasionnel"),
    Animal(69, "Sterne royale", "Thalasseus maximus", "🐦", "Oiseaux", "Commun"),
    Animal(70, "Sterne bridée", "Onychoprion anaethetus", "🐦", "Oiseaux", "Commun"),
    Animal(71, "Noddi brun", "Anous stolidus", "🐦", "Oiseaux", "Commun"),
    Animal(72, "Crabe de terre", "Gecarcinus ruricola", "🦀", "Crustacés", "Commun"),
    Animal(73, "Crabe à barbe", "Ucides cordatus", "🦀", "Crustacés", "Commun"),
    Animal(74, "Crabe de palétuvier", "Aratus pisonii", "🦀", "Crustacés", "Commun"),
    Animal(75, "Petit crabe nageur", "Pachygrapsus gracilis", "🦀", "Crustacés", "Commun"),
    Animal(76, "Crabe sémafot", "Uca rapax", "🦀", "Crustacés", "Commun"),
    Animal(77, "Crabe bleu", "Callinectes sapidus", "🦀", "Crustacés", "Commun"),
    Animal(78, "Langouste des Caraïbes", "Panulirus argus", "🦞", "Crustacés", "Commun"),
    Animal(79, "Cigale de mer", "Scyllarides aequinoctialis", "🦞", "Crustacés", "Rare"),
    Animal(80, "Lambi", "Lobatus gigas", "🐚", "Mollusques", "Rare"),
    Animal(81, "Poulpe commun", "Octopus vulgaris", "🐙", "Mollusques", "Commun"),
    Animal(82, "Mygale de Guadeloupe", "Holothele longipes", "🕷️", "Arachnides", "Rare"),
    Animal(83, "Scorpion des Antilles", "Centruroides sp.", "🦂", "Arachnides", "Rare"),
    Animal(84, "Papillon monarque", "Danaus plexippus", "🦋", "Papillons", "Commun"),
    Animal(85, "Flambeau commun", "Dryas iulia", "🦋", "Papillons", "Commun"),
    Animal(86, "Papillon zèbre", "Heliconius charithonia", "🦋", "Papillons", "Commun"),
    Animal(87, "Papillon tacheté de l’orange", "Anartia jatrophae", "🦋", "Papillons", "Commun"),
    Animal(88, "Papillon queue-de-jonc", "Papilio andraemon", "🦋", "Papillons", "Rare"),
    Animal(89, "Papillon flamboyant", "Heraclides thoas", "🦋", "Papillons", "Commun"),
    Animal(90, "Poisson-papillon rayé", "Chaetodon striatus", "🐠", "Poissons", "Commun"),
    Animal(91, "Poisson-perroquet feu", "Sparisoma viride", "🐠", "Poissons", "Commun"),
    Animal(92, "Poisson-chirurgien bleu", "Acanthurus coeruleus", "🐠", "Poissons", "Commun"),
    Animal(93, "Poisson-chirurgien océanique", "Acanthurus bahianus", "🐠", "Poissons", "Commun"),
    Animal(94, "Pagre jaune", "Lutjanus apodus", "🐠", "Poissons", "Commun"),
    Animal(95, "Serran rayé", "Serranus striatus", "🐠", "Poissons", "Commun"),
    Animal(96, "Barracuda", "Sphyraena barracuda", "🐟", "Poissons", "Commun"),
    Animal(97, "Raie pastenague américaine", "Hypanus americanus", "🐟", "Poissons", "Commun"),
    Animal(98, "Requin nourrice", "Ginglymostoma cirratum", "🦈", "Requins", "Occasionnel"),
    Animal(99, "Requin citron", "Negaprion brevirostris", "🦈", "Requins", "Rare"),
    Animal(100, "Requin-baleine", "Rhincodon typus", "🦈", "Requins", "Très rare"),
)
class MainActivity:androidx.activity.ComponentActivity(){override fun onCreate(b:android.os.Bundle?){super.onCreate(b);setContent{App()}}}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("dex", Context.MODE_PRIVATE) }
    var seen by remember {
        mutableStateOf(
            prefs.getStringSet("seen", emptySet())!!
                .mapNotNull { it.toIntOrNull() }
                .toSet()
        )
    }
    var fav by remember {
        mutableStateOf(
            prefs.getStringSet("fav", emptySet())!!
                .mapNotNull { it.toIntOrNull() }
                .toSet()
        )
    }
    var tab by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Animal?>(null) }

    fun save() {
        prefs.edit()
            .putStringSet("seen", seen.map(Int::toString).toSet())
            .putStringSet("fav", fav.map(Int::toString).toSet())
            .apply()
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Color(0xFF1565C0),
            secondary = Color(0xFFFFC107)
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("GuadeloupeDex", fontWeight = FontWeight.Bold) },
                    actions = {
                        Text("${seen.size}/100", modifier = Modifier.padding(end = 16.dp))
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = tab == 0,
                        onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.List, null) },
                        label = { Text("Pokédex") }
                    )
                    NavigationBarItem(
                        selected = tab == 1,
                        onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.CameraAlt, null) },
                        label = { Text("Photo") }
                    )
                    NavigationBarItem(
                        selected = tab == 2,
                        onClick = { tab = 2 },
                        icon = { Icon(Icons.Default.Star, null) },
                        label = { Text("Favoris") }
                    )
                }
            }
        ) { pad ->
            if (selected != null) {
                val animal = selected!!
                Detail(
                    animal,
                    seen.contains(animal.id),
                    fav.contains(animal.id),
                    { selected = null },
                    {
                        seen = if (seen.contains(animal.id)) seen - animal.id else seen + animal.id
                        save()
                    },
                    {
                        fav = if (fav.contains(animal.id)) fav - animal.id else fav + animal.id
                        save()
                    },
                    Modifier.padding(pad)
                )
            } else {
                when (tab) {
                    0 -> Dex(animals, seen, { selected = it }, Modifier.padding(pad))
                    1 -> Photo({ selected = it }, Modifier.padding(pad))
                    else -> Dex(
                        animals.filter { fav.contains(it.id) },
                        seen,
                        { selected = it },
                        Modifier.padding(pad)
                    )
                }
            }
        }
    }
}
}

@Composable fun Dex(list:List<Animal>,seen:Set<Int>,select:(Animal)->Unit,mod:Modifier){var q by remember{mutableStateOf("")};var cat by remember{mutableStateOf("Tous")};val cats=list.map{it.category}.distinct();val filtered=list.filter{(q.isBlank()||it.name.contains(q,true)||it.scientific.contains(q,true))&&(cat=="Tous"||it.category==cat)};Column(mod.fillMaxSize()){LinearProgressIndicator(progress={seen.size/100f},modifier=Modifier.fillMaxWidth());OutlinedTextField(q,{q=it},modifier=Modifier.fillMaxWidth().padding(12.dp),singleLine=true,label={Text("Rechercher un animal")},leadingIcon={Icon(Icons.Default.Search,null)});Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal=12.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){(listOf("Tous")+cats).forEach{c->FilterChip(cat==c,{cat=c},label={Text(c)})}};LazyVerticalGrid(GridCells.Fixed(2),Modifier.fillMaxSize().padding(8.dp),contentPadding=PaddingValues(bottom=90.dp)){items(filtered,key={it.id}){a->Card(onClick={select(a)},modifier=Modifier.padding(6.dp),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(14.dp),horizontalAlignment=Alignment.CenterHorizontally){Text("#%03d".format(a.id),style=MaterialTheme.typography.labelMedium);Text(a.icon,style=MaterialTheme.typography.displaySmall);Text(a.name,fontWeight=FontWeight.Bold);Text(a.category,style=MaterialTheme.typography.bodySmall);Text(a.rarity,style=MaterialTheme.typography.labelSmall);if(seen.contains(a.id))Text("✓ Vu",color=MaterialTheme.colorScheme.primary)}}}}}
@Composable fun Detail(a:Animal,isSeen:Boolean,isFav:Boolean,back:()->Unit,toggleSeen:()->Unit,toggleFav:()->Unit,mod:Modifier){Column(mod.fillMaxSize().padding(20.dp)){Row(verticalAlignment=Alignment.CenterVertically){IconButton(onClick=back){Icon(Icons.Default.ArrowBack,"Retour")};Text("#%03d".format(a.id),style=MaterialTheme.typography.titleLarge)};Spacer(Modifier.height(20.dp));Text(a.icon,style=MaterialTheme.typography.displayLarge,modifier=Modifier.align(Alignment.CenterHorizontally));Text(a.name,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text(a.scientific,style=MaterialTheme.typography.bodyLarge);Spacer(Modifier.height(12.dp));Text("Catégorie : ${a.category}");Text("Rareté : ${a.rarity}");Spacer(Modifier.height(24.dp));Button(toggleSeen,Modifier.fillMaxWidth()){Text(if(isSeen)"Marquer non vu" else "Je l'ai vu !")};OutlinedButton(toggleFav,Modifier.fillMaxWidth()){Icon(if(isFav)Icons.Default.Star else Icons.Default.StarBorder,null);Spacer(Modifier.width(8.dp));Text(if(isFav)"Retirer des favoris" else "Ajouter aux favoris")}}}
@Composable
fun Photo(onCandidate: (Animal) -> Unit, mod: Modifier) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var result by remember { mutableStateOf("Choisis une photo ou prends une photo.") }
    var conf by remember { mutableStateOf<Float?>(null) }

    fun analyze(bitmap: Bitmap) {
        result = "Analyse en cours…"
        conf = null
        val image = InputImage.fromBitmap(bitmap, 0)
        ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS)
            .process(image)
            .addOnSuccessListener { labels ->
                val top = labels.maxByOrNull { it.confidence }
                if (top == null) {
                    result = "Aucun élément reconnu."
                } else {
                    result = top.text
                    conf = top.confidence
                    val label = top.text.lowercase()
                    val candidate = animals.firstOrNull {
                        label.contains(it.name.lowercase()) ||
                        (label.contains("bird") && it.category == "Oiseaux") ||
                        (label.contains("fish") && it.category == "Poissons") ||
                        (label.contains("turtle") && it.category == "Tortues marines") ||
                        (label.contains("butterfly") && it.category == "Papillons")
                    }
                    if (candidate != null && top.confidence >= 0.45f) {
                        onCandidate(candidate)
                    }
                }
            }
            .addOnFailureListener {
                result = "Erreur d'analyse : ${it.message ?: "inconnue"}"
            }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) analyze(bitmap)
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val bitmap = uriToBitmap(ctx, uri)
            if (bitmap != null) {
                analyze(bitmap)
            } else {
                result = "Impossible de lire cette image."
            }
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            cameraLauncher.launch(null)
        } else {
            result = "Autorisation caméra refusée."
        }
    }

    Column(
        mod.fillMaxSize().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "🔎 Identifier un animal",
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Spacer(Modifier.height(12.dp))
        Text("Reconnaissance photo — bêta")
        Text("Le modèle général reconnaît surtout des catégories et ne garantit pas l'espèce exacte.")
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = {
                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                    cameraLauncher.launch(null)
                } else {
                    permissionLauncher.launch(Manifest.permission.CAMERA)
                }
            }) {
                Icon(Icons.Default.CameraAlt, null)
                Spacer(Modifier.width(6.dp))
                Text("Caméra")
            }
            OutlinedButton(onClick = { galleryLauncher.launch("image/*") }) {
                Icon(Icons.Default.Photo, null)
                Spacer(Modifier.width(6.dp))
                Text("Galerie")
            }
        }
        Spacer(Modifier.height(30.dp))
        Text(result, style = MaterialTheme.typography.headlineSmall)
        conf?.let { Text("Confiance : ${(it * 100).toInt()} %") }
    }
}

fun uriToBitmap(context: Context, uri: Uri): Bitmap? {
    return try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val source = ImageDecoder.createSource(context.contentResolver, uri)
            ImageDecoder.decodeBitmap(source)
        } else {
            @Suppress("DEPRECATION")
            MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
        }
    } catch (_: Exception) {
        null
    }
}
