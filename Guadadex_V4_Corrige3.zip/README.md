# GuadeloupeDex 3.1

Pokédex Android de la faune de Guadeloupe.

## Cette version corrige
- Les photos ne sont plus associées arbitrairement à une espèce : recherche Wikimedia Commons stricte sur le nom scientifique.
- La reconnaissance photo ne sélectionne plus automatiquement le premier oiseau/reptile trouvé.
- Affichage des indices ML Kit et des espèces candidates.
- Bouton de partage de la photo vers une application de reconnaissance externe (par exemple Google Lens si disponible).
- Galerie et fiches détaillées conservées.

## Limite importante
ML Kit Image Labeling est un modèle généraliste : il ne fournit pas une identification fiable de 100 espèces de Guadeloupe. Une reconnaissance réellement au niveau de l'espèce nécessitera un modèle spécialisé entraîné sur les espèces du Pokédex. Cette version évite donc de présenter une espèce fausse comme certaine.
