# GuadeloupeDex V2
Pokédex Android de la faune de Guadeloupe.

Fonctions : 100 fiches, recherche, filtres, favoris, progression, photo/galerie et reconnaissance d'image ML Kit.

La reconnaissance intégrée est une bêta basée sur le modèle général ML Kit. Pour une identification précise espèce par espèce, il faudra ensuite intégrer un modèle personnalisé entraîné sur des photos d'espèces guadeloupéennes.

Build : `gradle assembleDebug`
