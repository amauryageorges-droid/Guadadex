# Guadadex V5

Pokédex mobile de la faune de Guadeloupe.

## Changements V5
- Refonte de l'interface façon Pokédex : accueil, espèces, reconnaissance, profil.
- Recherche d'espèces réactive avec nom français, nom scientifique et alias.
- Photos d'exemple séparées des observations personnelles.
- Recherche Wikimedia Commons améliorée avec User-Agent, requête scientifique puis fallback sur le nom français.
- Galerie d'exemples et galerie "Mes observations" dans chaque fiche.
- 150 espèces.
- Reconnaissance photo avec classement de candidats et conservation de la photo utilisée.

La reconnaissance ML Kit reste une aide générique : un modèle entraîné spécifiquement sur les espèces de Guadeloupe pourra remplacer le moteur de candidats ultérieurement.
