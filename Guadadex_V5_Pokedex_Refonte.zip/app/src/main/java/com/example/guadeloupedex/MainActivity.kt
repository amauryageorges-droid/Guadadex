package com.example.guadeloupedex

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.Normalizer

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GuadaDexApp() }
    }
}

data class Animal(
    val id: Int,
    val name: String,
    val scientific: String,
    val icon: String,
    val category: String,
    val rarity: String,
    val habitat: String,
    val diet: String,
    val size: String,
    val lifespan: String,
    val description: String,
    val observation: String,
    val aliases: List<String> = emptyList()
)

data class PhotoItem(val uri: String, val source: String)

private val bg = Color(0xFF06141C)
private val surface = Color(0xFF0E2530)
private val surface2 = Color(0xFF163743)
private val blue = Color(0xFF249BFF)
private val green = Color(0xFF38D27A)
private val red = Color(0xFFFF4050)
private val yellow = Color(0xFFFFD42A)
private val textSoft = Color(0xFFB9CAD0)

private fun A(id:Int,name:String,sci:String,icon:String,cat:String,rarity:String,hab:String,diet:String,size:String,life:String,desc:String,obs:String,aliases:List<String> = emptyList()) =
    Animal(id,name,sci,icon,cat,rarity,hab,diet,size,life,desc,obs,aliases)

// 150 espèces / groupes d'observation. Les fiches utilisent des données générales
// par espèce et la photo Wikimedia est recherchée sur le nom scientifique exact.
private val animals = listOf(
A(1,"Raton laveur de Guadeloupe","Procyon lotor","🦝","Mammifères","Rare","Forêts, zones humides et mangroves","Omnivore","50 à 70 cm","5 à 10 ans","Mammifère nocturne opportuniste, facilement reconnaissable à son masque facial.","Observer à distance la nuit et ne jamais le nourrir.",listOf("raccoon","procyon")),
A(2,"Iguane des Petites-Antilles","Iguana delicatissima","🦎","Reptiles","Très rare","Forêts sèches, falaises et littoral","Herbivore","Jusqu'à 1,4 m","10 à 15 ans","Iguane endémique des Petites-Antilles, très sensible aux introductions d'iguane vert.","Ne pas toucher et éviter les zones de reproduction.",listOf("iguana","lesser antillean iguana")),
A(3,"Iguane vert","Iguana iguana","🦎","Reptiles","Commun","Littoral, jardins et forêts sèches","Herbivore","Jusqu'à 2 m","8 à 12 ans","Grand lézard arboricole vert à longue queue.","Observer depuis le sol sans le poursuivre.",listOf("iguana","green iguana")),
A(4,"Anolis de Guadeloupe","Anolis marmoratus","🦎","Reptiles","Commun","Jardins, forêts et lisières","Insectivore","15 à 25 cm","3 à 5 ans","Petit lézard agile très fréquent dans les végétations tropicales.","Chercher sur les troncs et les feuilles au soleil.",listOf("anole","lizard")),
A(5,"Mabouya à pattes jaunes","Hemidactylus mabouia","🦎","Reptiles","Commun","Maisons, murs, jardins et rochers","Insectivore","10 à 15 cm","3 à 5 ans","Gecko nocturne souvent visible près des éclairages.","Éteindre les lumières inutiles pour limiter la perturbation.",listOf("gecko","house gecko")),
A(6,"Técadactyle","Thecadactylus rapicauda","🦎","Reptiles","Commun","Forêts et vieux bâtiments","Insectivore","20 à 30 cm","5 à 10 ans","Grand gecko nocturne aux doigts larges.","Observer discrètement après la tombée de la nuit.",listOf("gecko","large gecko")),
A(7,"Typhlops de Guadeloupe","Typhlops guadeloupensis","🐍","Reptiles","Très rare","Sols forestiers et litière","Petits invertébrés","15 à 30 cm","Inconnue","Petit serpent fouisseur difficile à observer.","Ne pas retourner les pierres ou la litière.",listOf("blind snake","snake")),
A(8,"Couresse de Guadeloupe","Alsophis antillensis","🐍","Reptiles","Très rare","Forêts et zones sèches","Carnivore","60 à 100 cm","Inconnue","Couleuvre terrestre agile et non venimeuse.","Garder ses distances et ne jamais tenter de la capturer.",listOf("snake","couresse")),
A(9,"Couresse des Saintes","Alsophis sanctonum","🐍","Reptiles","Très rare","Milieux secs des Saintes","Carnivore","60 à 90 cm","Inconnue","Couresse insulaire rare.","Respecter strictement les zones protégées.",listOf("snake")),
A(10,"Hylode de Pinchon","Eleutherodactylus pinchoni","🐸","Amphibiens","Rare","Forêts humides et ravines","Insectivore","2 à 4 cm","Quelques années","Petite grenouille forestière endémique de Guadeloupe.","Écouter les chants après la pluie sans manipuler les animaux.",listOf("frog","tree frog")),
A(11,"Hylode de Barlagne","Eleutherodactylus barlagnei","🐸","Amphibiens","Rare","Forêts humides","Insectivore","2 à 4 cm","Quelques années","Petite hylode discrète des forêts humides.","Éviter de marcher dans les ravines.",listOf("frog")),
A(12,"Hylode de la Martinique","Eleutherodactylus martinicensis","🐸","Amphibiens","Commun","Jardins et milieux humides","Insectivore","2 à 4 cm","Quelques années","Petite grenouille nocturne commune aux Antilles.","Écouter les chants au crépuscule.",listOf("frog")),
A(13,"Hylode de Johnstone","Eleutherodactylus johnstonei","🐸","Amphibiens","Commun","Jardins et zones urbaines humides","Insectivore","2 à 4 cm","Quelques années","Petite grenouille très adaptable.","Observer les végétations humides après la pluie.",listOf("frog")),
A(14,"Tortue verte","Chelonia mydas","🐢","Tortues marines","Rare","Herbiers, baies et plages","Herbivore adulte","Jusqu'à 1,2 m","60 ans et plus","Grande tortue marine fréquentant les eaux guadeloupéennes.","Ne pas éclairer les tortues et leurs nids la nuit.",listOf("sea turtle","turtle")),
A(15,"Tortue imbriquée","Eretmochelys imbricata","🐢","Tortues marines","Rare","Récifs coralliens et plages","Omnivore","70 à 100 cm","30 à 50 ans","Tortue marine au bec caractéristique et aux écailles imbriquées.","Respecter les distances d'observation.",listOf("sea turtle","turtle")),
A(16,"Tortue luth","Dermochelys coriacea","🐢","Tortues marines","Très rare","Large, zones côtières et plages","Méduses et invertébrés","Jusqu'à 1,8 m","45 ans et plus","Plus grande tortue marine actuelle.","Ne jamais approcher une femelle sur la plage.",listOf("leatherback turtle","sea turtle")),
A(17,"Tortue caouanne","Caretta caretta","🐢","Tortues marines","Occasionnel","Large et littoral","Carnivore","70 à 100 cm","50 ans et plus","Tortue marine à grosse tête.","Signaler les observations de ponte aux réseaux locaux.",listOf("loggerhead turtle","sea turtle")),
A(18,"Tortue olivâtre","Lepidochelys olivacea","🐢","Tortues marines","Occasionnel","Large et plages","Omnivore","60 à 75 cm","40 ans et plus","Petite tortue marine à carapace olivâtre.","Ne pas utiliser de flash près des pontes.",listOf("olive ridley turtle","sea turtle")),
A(19,"Sérotine de Guadeloupe","Eptesicus guadeloupensis","🦇","Chauves-souris","Très rare","Forêts et cavités","Insectivore","7 à 9 cm","Inconnue","Chauve-souris rare des Petites-Antilles.","Ne pas pénétrer dans les gîtes en période de reproduction.",listOf("bat")),
A(20,"Fer-de-lance commun","Artibeus jamaicensis","🦇","Chauves-souris","Commun","Forêts, jardins et zones agricoles","Fruits","8 à 10 cm","5 à 10 ans","Chauve-souris frugivore commune des Antilles.","Observer les sorties de gîte au crépuscule.",listOf("bat","fruit bat")),
A(21,"Sturnire de la Guadeloupe","Sturnira angeli","🦇","Chauves-souris","Rare","Forêts humides","Fruits","6 à 8 cm","Inconnue","Petite chauve-souris frugivore forestière.","Ne pas déranger les colonies.",listOf("bat")),
A(22,"Ardops des Petites-Antilles","Ardops nichollsi","🦇","Chauves-souris","Rare","Forêts et jardins","Fruits","6 à 8 cm","Inconnue","Chauve-souris frugivore des îles antillaises.","Observer sans lumière forte.",listOf("bat")),
A(23,"Monophylle des Petites-Antilles","Monophyllus plethodon","🦇","Chauves-souris","Rare","Grottes et forêts","Nectar et fruits","6 à 8 cm","Inconnue","Chauve-souris nectarivore importante pour la pollinisation.","Ne pas pénétrer dans les colonies.",listOf("bat")),
A(24,"Noctilion pêcheur","Noctilio leporinus","🦇","Chauves-souris","Rare","Rivières, lagunes et littoral","Poissons et crustacés","10 à 13 cm","10 ans environ","Chauve-souris spécialisée dans la capture de proies aquatiques.","Observer au-dessus de l'eau au crépuscule.",listOf("fishing bat","bat")),
A(25,"Pteronote de Davy","Pteronotus davyi","🦇","Chauves-souris","Rare","Grottes et forêts","Insectivore","5 à 7 cm","Inconnue","Chauve-souris insectivore vivant souvent en colonie.","Ne pas entrer dans les grottes sensibles.",listOf("bat")),
A(26,"Molosse commun","Molossus molossus","🦇","Chauves-souris","Commun","Zones urbaines et forêts","Insectivore","7 à 10 cm","5 à 10 ans","Chauve-souris rapide et souvent visible au-dessus des toits.","Observer au crépuscule.",listOf("bat")),
A(27,"Tadaride du Brésil","Tadarida brasiliensis","🦇","Chauves-souris","Commun","Falaises, bâtiments et zones ouvertes","Insectivore","7 à 10 cm","5 à 10 ans","Chauve-souris insectivore très mobile.","Observer les vols en groupe au coucher du soleil.",listOf("bat")),
A(28,"Dauphin tacheté pantropical","Stenella attenuata","🐬","Mammifères marins","Commun","Large et eaux tropicales","Poissons et calmars","1,7 à 2,4 m","30 ans environ","Dauphin marqué de taches chez l'adulte.","Ne jamais poursuivre les groupes en bateau.",listOf("dolphin")),
A(29,"Grand dauphin","Tursiops truncatus","🐬","Mammifères marins","Commun","Côtes et large","Poissons et céphalopodes","2 à 4 m","40 ans environ","Dauphin robuste et très répandu.","Garder une distance respectueuse en mer.",listOf("dolphin","bottlenose dolphin")),
A(30,"Dauphin commun","Delphinus delphis","🐬","Mammifères marins","Occasionnel","Large","Poissons et calmars","1,7 à 2,4 m","30 ans environ","Dauphin élancé vivant souvent en groupes.","Ne pas couper la route des animaux.",listOf("dolphin")),
A(31,"Dauphin de Fraser","Lagenodelphis hosei","🐬","Mammifères marins","Rare","Large tropical","Poissons et calmars","2 à 2,7 m","30 ans environ","Dauphin tropical aux flancs contrastés.","Observer depuis une distance sûre.",listOf("dolphin")),
A(32,"Dauphin à long bec","Stenella longirostris","🐬","Mammifères marins","Rare","Large tropical","Poissons et calmars","1,5 à 2,3 m","25 ans environ","Dauphin acrobatique pouvant sauter hors de l'eau.","Éviter les manœuvres brusques en bateau.",listOf("dolphin","spinner dolphin")),
A(33,"Dauphin tacheté de l’Atlantique","Stenella frontalis","🐬","Mammifères marins","Occasionnel","Large et côtes","Poissons et calmars","1,8 à 2,3 m","30 ans environ","Dauphin tacheté de l'Atlantique tropical.","Observer sans nourrir.",listOf("dolphin")),
A(34,"Globicéphale tropical","Globicephala macrorhynchus","🐋","Mammifères marins","Commun","Large","Calmars et poissons","4 à 7 m","40 ans environ","Grand cétacé à tête arrondie vivant en groupes sociaux.","Ne pas approcher les groupes.",listOf("pilot whale","whale")),
A(35,"Grand cachalot","Physeter macrocephalus","🐋","Mammifères marins","Rare","Large","Calmars et poissons profonds","10 à 18 m","60 ans et plus","Cétacé à très grande tête et plongée profonde.","Respecter les zones de navigation.",listOf("sperm whale","whale")),
A(36,"Cachalot nain","Kogia sima","🐋","Mammifères marins","Très rare","Large et talus","Calmars et poissons","2,5 à 3 m","20 ans environ","Petit cétacé discret des eaux profondes.","Observation exceptionnelle : ne pas poursuivre.",listOf("dwarf sperm whale","whale")),
A(37,"Baleine à bosse","Megaptera novaeangliae","🐋","Mammifères marins","Rare","Côtes et large","Krill et petits poissons","12 à 16 m","45 à 50 ans","Grande baleine migratrice visible aux Antilles en saison.","Réduire vitesse et distance autour des baleines.",listOf("humpback whale","whale")),
A(38,"Orque naine","Feresa attenuata","🐋","Mammifères marins","Très rare","Large tropical","Poissons et céphalopodes","2,1 à 2,7 m","Inconnue","Petit cétacé noir très peu observé.","Signaler les observations fiables aux réseaux de suivi.",listOf("melon-headed whale","whale")),
A(39,"Pseudorque","Pseudorca crassidens","🐋","Mammifères marins","Très rare","Large tropical","Poissons et calmars","4,5 à 6 m","50 ans environ","Grand dauphiniforme social des eaux chaudes.","Ne pas tenter d'approcher un groupe.",listOf("false killer whale","whale")),
A(40,"Pic de Guadeloupe","Melanerpes herminieri","🐦","Oiseaux","Rare","Forêts tropicales","Insectes, fruits et graines","25 à 28 cm","Plusieurs années","Seul pic endémique des Petites-Antilles, emblématique de l'archipel.","Chercher les troncs et écouter les tambourinages.",listOf("woodpecker","bird")),
A(41,"Crécerelle d’Amérique","Falco sparverius","🦅","Oiseaux","Commun","Zones ouvertes et agricoles","Insectes et petits vertébrés","22 à 31 cm","5 à 10 ans","Petit faucon souvent perché sur les fils et poteaux.","Observer aux lisières et prairies.",listOf("kestrel","falcon","bird")),
A(42,"Frégate superbe","Fregata magnificens","🦅","Oiseaux","Commun","Littoral et îlots","Poissons et proies capturées en surface","90 cm environ","15 à 20 ans","Oiseau marin aux longues ailes et au sac gulaire rouge chez le mâle.","Observer depuis la côte sans déranger les colonies.",listOf("frigatebird","bird")),
A(43,"Pélican brun","Pelecanus occidentalis","🐦","Oiseaux","Commun","Littoral, ports et mangroves","Poissons","1 à 1,4 m","15 à 25 ans","Grand oiseau marin plongeant pour capturer les poissons.","Ne pas nourrir les oiseaux près des ports.",listOf("pelican","bird")),
A(44,"Fou brun","Sula leucogaster","🐦","Oiseaux","Occasionnel","Îlots et pleine mer","Poissons","65 à 75 cm","10 à 15 ans","Oiseau marin plongeur brun et blanc.","Observer les plongées depuis un bateau à distance.",listOf("booby","bird")),
A(45,"Paille-en-queue à bec rouge","Phaethon aethereus","🐦","Oiseaux","Rare","Falaises et large","Poissons et calmars","90 cm avec queue","10 à 15 ans","Oiseau marin blanc aux longues plumes caudales.","Respecter les falaises de nidification.",listOf("tropicbird","bird")),
A(46,"Héron garde-bœufs","Bubulcus ibis","🐦","Oiseaux","Commun","Prairies, pâtures et zones humides","Insectes et petits vertébrés","45 à 55 cm","10 à 15 ans","Héron blanc souvent associé au bétail.","Observer les groupes dans les pâtures.",listOf("egret","heron","bird")),
A(47,"Héron vert","Butorides virescens","🐦","Oiseaux","Commun","Mangroves, mares et rivières","Poissons et invertébrés","40 à 50 cm","7 à 10 ans","Petit héron solitaire des zones humides.","Chercher immobile au bord de l'eau.",listOf("heron","bird")),
A(48,"Grande aigrette","Ardea alba","🐦","Oiseaux","Commun","Zones humides et littoral","Poissons et grenouilles","85 à 100 cm","10 à 15 ans","Grande aigrette blanche au long cou.","Observer les zones humides sans entrer dans les roselières.",listOf("great egret","egret","bird")),
A(49,"Aigrette neigeuse","Egretta thula","🐦","Oiseaux","Commun","Mangroves, vasières et étangs","Poissons et invertébrés","55 à 65 cm","10 à 15 ans","Petite aigrette blanche aux pattes sombres et doigts jaunes.","Observer depuis les berges.",listOf("snowy egret","egret","bird")),
A(50,"Aigrette bleue","Egretta caerulea","🐦","Oiseaux","Commun","Mangroves et zones humides","Poissons et invertébrés","55 à 75 cm","10 à 15 ans","Héron de taille moyenne au plumage bleu ardoise adulte.","Observer tôt le matin.",listOf("little blue heron","heron","bird")),
A(51,"Paruline jaune","Setophaga petechia","🐦","Oiseaux","Commun","Mangroves, jardins et lisières","Insectes","10 à 13 cm","5 à 10 ans","Petite paruline jaune très active dans les feuillages.","Écouter les chants dans les arbres bas.",listOf("warbler","bird")),
A(52,"Paruline caféiette","Setophaga plumbea","🐦","Oiseaux","Rare","Forêts","Insectes","12 à 14 cm","Plusieurs années","Paruline antillaise discrète des sous-bois.","Rester immobile pour l'observer.",listOf("warbler","bird")),
A(53,"Sporophile rouge-gorge","Loxigilla noctis","🐦","Oiseaux","Commun","Fourrés et forêts sèches","Graines et fruits","14 à 17 cm","5 à 10 ans","Petit passereau antillais robuste.","Observer dans les buissons fruitiers.",listOf("finch","bird")),
A(54,"Sucrier à ventre jaune","Coereba flaveola","🐦","Oiseaux","Très commun","Jardins, mangroves et forêts","Nectar et petits fruits","10 à 12 cm","5 à 8 ans","Petit oiseau jaune très fréquent aux mangeoires naturelles.","Chercher les fleurs et arbres fruitiers.",listOf("bananaquit","bird")),
A(55,"Trembleur brun","Cinclocerthia ruficauda","🐦","Oiseaux","Commun","Forêts et sous-bois","Insectes et fruits","23 à 26 cm","Plusieurs années","Oiseau brun au comportement très actif dans la litière.","Observer au sol des sous-bois.",listOf("thrasher","bird")),
A(56,"Merle à lunettes","Turdus nudigenis","🐦","Oiseaux","Commun","Jardins et forêts","Fruits et invertébrés","23 à 27 cm","5 à 10 ans","Merle sombre à cercle orbital clair.","Observer dans les pelouses et sous-bois.",listOf("thrush","bird")),
A(57,"Quiscale merle","Quiscalus lugubris","🐦","Oiseaux","Commun","Zones urbaines et agricoles","Graines, fruits et invertébrés","25 à 30 cm","5 à 10 ans","Passereau sombre et vocal des zones habitées.","Observer sans nourrissage.",listOf("grackle","bird")),
A(58,"Moqueur grivotte","Margarops fuscatus","🐦","Oiseaux","Commun","Forêts sèches et jardins","Fruits et invertébrés","25 à 30 cm","Plusieurs années","Grand moqueur gris-brun des Antilles.","Écouter ses cris rauques dans les fourrés.",listOf("mockingbird","bird")),
A(59,"Colibri madère","Eulampis jugularis","🐦","Oiseaux","Commun","Forêts humides et jardins fleuris","Nectar et insectes","11 à 13 cm","5 à 8 ans","Colibri coloré associé aux fleurs des forêts.","Observer sans installer de nourriture artificielle.",listOf("hummingbird","bird")),
A(60,"Colibri huppé","Orthorhyncus cristatus","🐦","Oiseaux","Commun","Jardins et forêts","Nectar et petits insectes","8 à 9 cm","5 à 8 ans","Petit colibri à huppe caractéristique.","Chercher les fleurs ensoleillées.",listOf("hummingbird","bird")),
A(61,"Colibri falle-vert","Eulampis holosericeus","🐦","Oiseaux","Commun","Jardins et lisières","Nectar et insectes","10 à 12 cm","5 à 8 ans","Colibri antillais au plumage vert et bleu.","Rester immobile près des floraisons.",listOf("hummingbird","bird")),
A(62,"Tourterelle à queue carrée","Zenaida aurita","🐦","Oiseaux","Commun","Zones urbaines et littoral","Graines et fruits","28 à 33 cm","5 à 10 ans","Tourterelle fréquente des Antilles.","Observer dans les zones ouvertes.",listOf("dove","bird")),
A(63,"Tourterelle triste","Zenaida macroura","🐦","Oiseaux","Commun","Zones ouvertes","Graines","30 à 35 cm","5 à 10 ans","Tourterelle migratrice parfois observée dans l'archipel.","Observer les zones agricoles.",listOf("mourning dove","dove","bird")),
A(64,"Colombe à queue noire","Columbina passerina","🐦","Oiseaux","Commun","Zones sèches et jardins","Graines","16 à 18 cm","5 ans environ","Petite colombe terrestre des zones sèches.","Chercher au sol près des haies.",listOf("ground dove","dove","bird")),
A(65,"Moucherolle gobe-mouches","Contopus latirostris","🐦","Oiseaux","Rare","Forêts et lisières","Insectes","15 à 18 cm","Plusieurs années","Moucherolle antillais qui chasse depuis un perchoir.","Observer les départs rapides depuis les branches.",listOf("flycatcher","bird")),
A(66,"Balbuzard pêcheur","Pandion haliaetus","🦅","Oiseaux","Occasionnel","Littoral et zones humides","Poissons","50 à 65 cm","15 à 20 ans","Rapace spécialisé dans la pêche.","Observer depuis la côte sans approcher les nids.",listOf("osprey","bird")),
A(67,"Hirondelle à ventre blanc","Progne dominicensis","🐦","Oiseaux","Commun","Zones ouvertes et urbaines","Insectes volants","18 à 20 cm","5 à 10 ans","Hirondelle sombre à ventre clair.","Observer les vols au-dessus des prairies.",listOf("martin","swallow","bird")),
A(68,"Martinet ramoneur","Chaetura pelagica","🐦","Oiseaux","Occasionnel","Ciel ouvert et zones urbaines","Insectes volants","12 à 14 cm","5 à 10 ans","Martinet migrateur très rapide.","Observer en vol plutôt qu'au sol.",listOf("swift","bird")),
A(69,"Sterne royale","Thalasseus maximus","🐦","Oiseaux","Commun","Plages, bancs de sable et mer","Poissons","45 à 50 cm","15 à 20 ans","Grande sterne au bec orange.","Ne pas déranger les reposoirs.",listOf("tern","bird")),
A(70,"Sterne bridée","Onychoprion anaethetus","🐦","Oiseaux","Commun","Îlots rocheux et large","Poissons","30 à 35 cm","10 à 15 ans","Petite sterne sombre et blanche.","Observer depuis le large à distance.",listOf("tern","bird")),
A(71,"Noddi brun","Anous stolidus","🐦","Oiseaux","Commun","Îlots et mer","Poissons et petits organismes marins","38 à 45 cm","15 à 20 ans","Oiseau marin brun fréquent autour des îlots.","Respecter les colonies.",listOf("noddy","bird")),
A(72,"Crabe de terre","Gecarcinus ruricola","🦀","Crustacés","Commun","Forêts littorales et zones terrestres","Détritus, feuilles et végétaux","Jusqu'à 12 cm","10 ans environ","Crabe terrestre coloré, surtout actif la nuit.","Ne pas le déplacer des routes de migration.",listOf("land crab","crab")),
A(73,"Crabe à barbe","Ucides cordatus","🦀","Crustacés","Commun","Mangroves et vasières","Feuilles et détritus","Jusqu'à 15 cm","Plusieurs années","Grand crabe associé aux mangroves.","Ne pas dégrader les terriers.",listOf("crab","mangrove crab")),
A(74,"Crabe de palétuvier","Aratus pisonii","🦀","Crustacés","Commun","Palétuviers","Feuilles de mangrove","4 à 5 cm","Quelques années","Petit crabe arboricole des mangroves.","Observer les troncs sans arracher les feuilles.",listOf("crab","mangrove crab")),
A(75,"Petit crabe nageur","Pachygrapsus gracilis","🦀","Crustacés","Commun","Rochers et littoral","Algues et détritus","3 à 5 cm","Quelques années","Petit crabe agile des rochers.","Observer dans les flaques sans retourner les pierres.",listOf("crab")),
A(76,"Crabe sémafot","Uca rapax","🦀","Crustacés","Commun","Vasières et mangroves","Détritus et microalgues","3 à 5 cm","Quelques années","Crabe violoniste des vasières.","Ne pas piétiner les terriers.",listOf("fiddler crab","crab")),
A(77,"Crabe bleu","Callinectes sapidus","🦀","Crustacés","Commun","Lagunes et estuaires","Omnivore","Jusqu'à 20 cm","2 à 3 ans","Crabe nageur bleu des eaux côtières.","Manipuler avec prudence si observation scientifique.",listOf("blue crab","crab")),
A(78,"Langouste des Caraïbes","Panulirus argus","🦞","Crustacés","Commun","Récifs et herbiers","Omnivore","20 à 45 cm","10 à 15 ans","Grande langouste sans pinces massives.","Respecter les tailles et périodes réglementaires.",listOf("spiny lobster","lobster")),
A(79,"Cigale de mer","Scyllarides aequinoctialis","🦞","Crustacés","Rare","Récifs et fonds rocheux","Invertébrés","20 à 30 cm","Plusieurs années","Crustacé aplati nocturne.","Observer sous l'eau sans le capturer.",listOf("slipper lobster","lobster")),
A(80,"Lambi","Lobatus gigas","🐚","Mollusques","Rare","Herbiers et fonds sableux","Algues et détritus","Jusqu'à 30 cm","20 ans et plus","Grand coquillage emblématique des Caraïbes.","Respecter les réglementations de pêche.",listOf("queen conch","conch","snail")),
A(81,"Poulpe commun","Octopus vulgaris","🐙","Mollusques","Commun","Récifs et fonds rocheux","Crustacés et poissons","Jusqu'à 1 m","1 à 2 ans","Céphalopode intelligent capable de changer rapidement de couleur.","Ne pas le toucher ou le nourrir.",listOf("octopus")),
A(82,"Mygale de Guadeloupe","Holothele longipes","🕷️","Arachnides","Rare","Forêts et sols humides","Insectes et petits invertébrés","Jusqu'à 10 cm","Plusieurs années","Mygale terrestre discrète.","Ne pas manipuler.",listOf("tarantula","spider")),
A(83,"Scorpion des Antilles","Centruroides sp.","🦂","Arachnides","Rare","Pierres, bois et bâtiments","Insectes","5 à 8 cm","Quelques années","Petit scorpion antillais.","Ne pas soulever les pierres à mains nues.",listOf("scorpion")),
A(84,"Papillon monarque","Danaus plexippus","🦋","Papillons","Commun","Jardins et zones fleuries","Nectar; chenille sur asclépiades","8 à 10 cm","Quelques semaines à mois","Grand papillon orange et noir.","Observer les plantes hôtes sans les arracher.",listOf("monarch","butterfly")),
A(85,"Flambeau commun","Dryas iulia","🦋","Papillons","Commun","Lisières et jardins","Nectar","7 à 9 cm","Quelques semaines","Papillon orange très actif au soleil.","Chercher les zones fleuries.",listOf("butterfly")),
A(86,"Papillon zèbre","Heliconius charithonia","🦋","Papillons","Commun","Forêts, jardins et lisières","Nectar; chenille sur passiflores","7 à 9 cm","Plusieurs semaines","Papillon noir rayé de jaune très reconnaissable.","Observer près des passiflores.",listOf("zebra longwing","butterfly")),
A(87,"Papillon tacheté de l’orange","Anartia jatrophae","🦋","Papillons","Commun","Zones humides et jardins","Nectar","5 à 6 cm","Quelques semaines","Petit papillon brun et orange.","Chercher sur les herbes fleuries.",listOf("peacock butterfly","butterfly")),
A(88,"Papillon queue-de-jonc","Papilio andraemon","🦋","Papillons","Rare","Forêts sèches et jardins","Nectar","8 à 10 cm","Quelques semaines","Grand papillon swallowtail des Antilles.","Observer les lisières fleuries.",listOf("swallowtail","butterfly")),
A(89,"Papillon flamboyant","Heraclides thoas","🦋","Papillons","Commun","Jardins et lisières","Nectar","9 à 12 cm","Quelques semaines","Grand papillon jaune et noir.","Chercher près des agrumes et fleurs.",listOf("swallowtail","butterfly")),
A(90,"Poisson-papillon rayé","Chaetodon striatus","🐠","Poissons","Commun","Récifs coralliens","Invertébrés et petits polypes","15 à 18 cm","5 à 10 ans","Poisson de récif à bandes verticales.","Observer sans toucher le corail.",listOf("butterflyfish","fish")),
A(91,"Poisson-perroquet feu","Sparisoma viride","🐠","Poissons","Commun","Récifs et herbiers","Algues","30 à 45 cm","5 à 10 ans","Poisson-perroquet important pour la santé des récifs.","Ne pas nourrir les poissons.",listOf("parrotfish","fish")),
A(92,"Poisson-chirurgien bleu","Acanthurus coeruleus","🐠","Poissons","Commun","Récifs et herbiers","Algues","20 à 35 cm","10 ans environ","Poisson bleu vif aux nageoires jaunes.","Observer sans poursuivre.",listOf("blue tang","surgeonfish","fish")),
A(93,"Poisson-chirurgien océanique","Acanthurus bahianus","🐠","Poissons","Commun","Récifs","Algues","20 à 30 cm","10 ans environ","Chirurgien sombre fréquent des récifs.","Observer en snorkeling sans toucher le fond.",listOf("surgeonfish","fish")),
A(94,"Pagre jaune","Lutjanus apodus","🐠","Poissons","Commun","Récifs et mangroves","Poissons et crustacés","30 à 60 cm","10 à 20 ans","Vivaneau fréquent des zones côtières.","Observer dans les cavités des récifs.",listOf("schoolmaster snapper","snapper","fish")),
A(95,"Serran rayé","Serranus striatus","🐠","Poissons","Commun","Récifs rocheux","Petits poissons et crustacés","15 à 25 cm","Quelques années","Petit serran rayé des fonds rocheux.","Observer sous les surplombs.",listOf("grouper","fish")),
A(96,"Barracuda","Sphyraena barracuda","🐟","Poissons","Commun","Récifs, tombants et pleine eau","Poissons","1 à 2 m","10 à 15 ans","Grand prédateur fuselé aux dents visibles.","Garder ses distances et ne jamais le nourrir.",listOf("barracuda","fish")),
A(97,"Raie pastenague américaine","Hypanus americanus","🐟","Poissons","Commun","Fonds sableux et herbiers","Crustacés et mollusques","Jusqu'à 1,5 m","15 ans environ","Grande raie des fonds côtiers.","Ne pas marcher sur les fonds où elles reposent.",listOf("stingray","ray")),
A(98,"Requin nourrice","Ginglymostoma cirratum","🦈","Requins","Occasionnel","Fonds rocheux, grottes et récifs","Poissons et crustacés","2 à 4 m","20 à 30 ans","Requin benthique souvent posé sur le fond.","Ne jamais toucher ni nourrir.",listOf("nurse shark","shark")),
A(99,"Requin citron","Negaprion brevirostris","🦈","Requins","Rare","Baies, mangroves et récifs","Poissons et raies","2 à 3 m","25 à 30 ans","Grand requin côtier jaunâtre.","Observer uniquement avec des opérateurs responsables.",listOf("lemon shark","shark")),
A(100,"Requin-baleine","Rhincodon typus","🦈","Requins","Très rare","Large tropical","Plancton et petits poissons","Jusqu'à 12 m","70 ans et plus","Plus grand poisson vivant, parfaitement inoffensif pour l'humain.","Ne jamais toucher ou bloquer sa trajectoire.",listOf("whale shark","shark")),
A(101,"Baleine de Bryde","Balaenoptera brydei","🐋","Mammifères marins","Rare","Large tropical","Poissons et krill","12 à 15 m","50 ans environ","Rorqual tropical difficile à distinguer des espèces proches.","Conserver une grande distance en mer.",listOf("bryde's whale","whale")),
A(102,"Rorqual commun","Balaenoptera physalus","🐋","Mammifères marins","Occasionnel","Large","Krill et petits poissons","18 à 24 m","70 ans et plus","Deuxième plus grand animal vivant.","Signaler les observations lointaines.",listOf("fin whale","whale")),
A(103,"Rorqual à museau pointu","Balaenoptera acutorostrata","🐋","Mammifères marins","Occasionnel","Large","Poissons et krill","7 à 10 m","40 à 50 ans","Petit rorqual migrateur.","Ne pas poursuivre les individus.",listOf("minke whale","whale")),
A(104,"Ziphius de Cuvier","Ziphius cavirostris","🐋","Mammifères marins","Rare","Talus continental et large","Calmars","5 à 7 m","40 ans environ","Baleine à bec des eaux profondes.","Observation rare : éviter toute approche.",listOf("cuvier's beaked whale","whale")),
A(105,"Dauphin bleu et blanc","Stenella coeruleoalba","🐬","Mammifères marins","Rare","Large","Poissons et calmars","2 à 2,5 m","40 ans environ","Dauphin au motif bleu-gris caractéristique.","Observer sans poursuite.",listOf("striped dolphin","dolphin")),
A(106,"Dauphin clymène","Stenella clymene","🐬","Mammifères marins","Rare","Large tropical","Poissons et calmars","1,7 à 2 m","30 ans environ","Petit dauphin tropical au rostre fin.","Ne pas couper la route des groupes.",listOf("clymene dolphin","dolphin")),
A(107,"Ibis blanc","Eudocimus albus","🐦","Oiseaux","Occasionnel","Mangroves, vasières et zones humides","Crustacés et invertébrés","55 à 70 cm","15 ans environ","Grand échassier blanc au bec courbé.","Observer les vasières depuis les sentiers.",listOf("white ibis","ibis","bird")),
A(108,"Spatule rosée","Platalea ajaja","🐦","Oiseaux","Rare","Mangroves et lagunes","Crustacés et poissons","70 à 90 cm","10 à 15 ans","Grand échassier rose au bec en spatule.","Ne pas approcher les reposoirs.",listOf("roseate spoonbill","spoonbill","bird")),
A(109,"Bihoreau gris","Nycticorax nycticorax","🐦","Oiseaux","Occasionnel","Mangroves et étangs","Poissons et amphibiens","58 à 65 cm","10 à 15 ans","Héron nocturne trapu.","Observer au crépuscule.",listOf("night heron","heron","bird")),
A(110,"Bihoreau violacé","Nyctanassa violacea","🐦","Oiseaux","Commun","Mangroves et littoral","Crustacés et poissons","55 à 70 cm","10 à 15 ans","Héron crépusculaire des zones côtières.","Chercher sur les racines de palétuviers.",listOf("yellow-crowned night heron","heron","bird")),
A(111,"Aigrette tricolore","Egretta tricolor","🐦","Oiseaux","Occasionnel","Lagunes et mangroves","Poissons et crustacés","60 à 75 cm","10 à 15 ans","Héron élancé au plumage gris bleuté.","Observer depuis les berges.",listOf("tricolored heron","heron","bird")),
A(112,"Dendrocygne fauve","Dendrocygna bicolor","🐦","Oiseaux","Occasionnel","Étangs et marais","Graines et plantes aquatiques","45 à 55 cm","10 ans environ","Canard tropical brun des zones humides.","Ne pas nourrir les oiseaux d'eau.",listOf("fulvous whistling duck","duck","bird")),
A(113,"Sarcelle à ailes bleues","Spatula discors","🐦","Oiseaux","Occasionnel","Étangs et marais","Graines et invertébrés","35 à 40 cm","5 à 10 ans","Petit canard migrateur.","Observer les zones humides sans s'en approcher.",listOf("blue-winged teal","duck","bird")),
A(114,"Martin-pêcheur d'Amérique","Megaceryle alcyon","🐦","Oiseaux","Occasionnel","Rivières et littoral","Poissons","28 à 35 cm","10 ans environ","Martin-pêcheur migrateur reconnaissable à sa huppe.","Chercher les perchoirs au-dessus de l'eau.",listOf("kingfisher","bird")),
A(115,"Pluvier argenté","Pluvialis squatarola","🐦","Oiseaux","Occasionnel","Plages et vasières","Invertébrés","27 à 31 cm","10 ans environ","Oiseau limicole migrateur fréquentant les vasières.","Observer à distance sur le littoral.",listOf("black-bellied plover","plover","bird")),
A(116,"Bécasseau sanderling","Calidris alba","🐦","Oiseaux","Commun","Plages et hauts de plage","Petits invertébrés","18 à 21 cm","5 à 10 ans","Petit limicole courant au bord des vagues.","Ne pas courir vers les groupes.",listOf("sanderling","sandpiper","bird")),
A(117,"Chevalier semipalmé","Tringa semipalmata","🐦","Oiseaux","Occasionnel","Vasières et mangroves","Invertébrés et petits poissons","33 à 41 cm","10 à 15 ans","Grand limicole migrateur aux pattes longues.","Observer depuis les sentiers.",listOf("willet","sandpiper","bird")),
A(118,"Mouette atricille","Leucophaeus atricilla","🐦","Oiseaux","Commun","Plages, ports et îlots","Poissons et détritus","40 à 45 cm","15 ans environ","Mouette très fréquente du littoral caribéen.","Ne pas nourrir près des ports.",listOf("laughing gull","gull","bird")),
A(119,"Sterne caspienne","Hydroprogne caspia","🐦","Oiseaux","Occasionnel","Littoral et lagunes","Poissons","48 à 55 cm","15 à 20 ans","Grande sterne au bec rouge puissant.","Respecter les reposoirs.",listOf("Caspian tern","tern","bird")),
A(120,"Poisson-ange français","Pomacanthus paru","🐠","Poissons","Commun","Récifs coralliens","Éponges et invertébrés","25 à 40 cm","10 à 15 ans","Poisson-ange sombre aux marques jaunes.","Observer sans toucher les coraux.",listOf("French angelfish","angelfish","fish")),
A(121,"Poisson-ange reine","Holacanthus ciliaris","🐠","Poissons","Commun","Récifs","Éponges et algues","25 à 45 cm","10 à 15 ans","Poisson-ange bleu et jaune spectaculaire.","Ne pas nourrir les poissons.",listOf("queen angelfish","angelfish","fish")),
A(122,"Poisson-lion","Pterois volitans","🐠","Poissons","Commun","Récifs et épaves","Petits poissons","25 à 40 cm","10 ans environ","Espèce introduite aux épines venimeuses.","Ne jamais toucher.",listOf("lionfish","fish")),
A(123,"Rascasse volante","Pterois miles","🐠","Poissons","Rare","Récifs et fonds rocheux","Poissons et crustacés","25 à 40 cm","10 ans environ","Poisson-lion proche de Pterois volitans.","Ne pas manipuler à cause des épines venimeuses.",listOf("lionfish","fish")),
A(124,"Mérou brun","Epinephelus marginatus","🐠","Poissons","Rare","Récifs rocheux","Poissons et crustacés","50 à 150 cm","20 ans et plus","Grand mérou des fonds rocheux.","Respecter les tailles et zones de protection.",listOf("dusky grouper","grouper","fish")),
A(125,"Mérou de Nassau","Epinephelus striatus","🐠","Poissons","Rare","Récifs et tombants","Poissons et crustacés","50 à 100 cm","20 ans et plus","Grand mérou des Caraïbes en déclin dans plusieurs régions.","Ne pas chasser les individus.",listOf("Nassau grouper","grouper","fish")),
A(126,"Poisson-coffre jaune","Acanthostracion polygonius","🐠","Poissons","Commun","Récifs et herbiers","Algues et petits invertébrés","20 à 30 cm","5 à 10 ans","Poisson au corps rigide et anguleux.","Observer les cavités des récifs.",listOf("cowfish","boxfish","fish")),
A(127,"Poisson porc-épic","Diodon holocanthus","🐡","Poissons","Commun","Récifs et herbiers","Crustacés et mollusques","30 à 50 cm","5 à 10 ans","Poisson-globe à grands yeux et épines.","Ne pas le poursuivre ni le toucher.",listOf("porcupinefish","pufferfish","fish")),
A(128,"Murène verte","Gymnothorax funebris","🐍","Poissons","Commun","Récifs et cavités","Poissons et crustacés","Jusqu'à 2,4 m","10 à 20 ans","Grande murène verte cachée dans les crevasses.","Ne jamais mettre la main dans les trous.",listOf("green moray","moray eel","fish")),
A(129,"Murène tachetée","Gymnothorax moringa","🐍","Poissons","Commun","Récifs rocheux","Poissons et crustacés","Jusqu'à 2 m","10 à 20 ans","Murène sombre et tachetée.","Observer à distance.",listOf("spotted moray","moray eel","fish")),
A(130,"Tarpon atlantique","Megalops atlanticus","🐟","Poissons","Occasionnel","Mangroves, lagunes et côtes","Poissons et crustacés","1 à 2,5 m","30 ans environ","Grand poisson argenté des eaux côtières.","Ne pas manipuler les gros individus.",listOf("tarpon","fish")),
A(131,"Albula des Caraïbes","Albula vulpes","🐟","Poissons","Rare","Herbiers et fonds sableux","Crustacés","50 à 100 cm","10 à 20 ans","Poisson argenté recherché dans les faibles profondeurs.","Observer sans marcher sur les herbiers.",listOf("bonefish","fish")),
A(132,"Permis","Trachinotus falcatus","🐟","Poissons","Rare","Plages et récifs","Crustacés et petits poissons","50 à 120 cm","10 à 15 ans","Grand carangue argenté des eaux peu profondes.","Respecter la réglementation de pêche.",listOf("permit fish","fish")),
A(133,"Raie aigle tachetée","Aetobatus narinari","🐟","Poissons","Rare","Sable, herbiers et récifs","Mollusques et crustacés","Jusqu'à 2,5 m d'envergure","15 à 20 ans","Grande raie aux motifs tachetés.","Ne pas poursuivre les raies en plongée.",listOf("spotted eagle ray","ray")),
A(134,"Requin pointe noire","Carcharhinus melanopterus","🦈","Requins","Rare","Récifs et lagons","Poissons et crustacés","1,5 à 2 m","20 ans environ","Petit requin côtier à pointe noire sur les nageoires.","Observer avec distance et calme.",listOf("blacktip reef shark","shark")),
A(135,"Requin pointe blanche de récif","Triaenodon obesus","🦈","Requins","Rare","Récifs et grottes","Poissons et crustacés","1,5 à 2,1 m","20 à 25 ans","Requin de récif souvent posé au fond.","Ne pas entrer dans les grottes avec lui.",listOf("whitetip reef shark","shark")),
A(136,"Requin marteau halicorne","Sphyrna lewini","🦈","Requins","Rare","Large et côtes","Poissons, raies et céphalopodes","2 à 4 m","20 à 30 ans","Requin marteau à tête très large.","Observation à distance uniquement.",listOf("scalloped hammerhead","hammerhead","shark")),
A(137,"Requin bouledogue","Carcharhinus leucas","🦈","Requins","Rare","Côtes, estuaires et rivières","Poissons et crustacés","2 à 3,5 m","20 à 30 ans","Grand requin côtier capable de fréquenter les eaux saumâtres.","Ne jamais s'approcher.",listOf("bull shark","shark")),
A(138,"Oursin diadème","Diadema antillarum","🦔","Échinodermes","Commun","Récifs coralliens","Algues","10 à 20 cm","Quelques années","Oursin noir aux très longues épines.","Ne pas toucher et éviter de marcher sur le récif.",listOf("long-spined sea urchin","urchin")),
A(139,"Oursin casque","Tripneustes ventricosus","🦔","Échinodermes","Commun","Herbiers et récifs","Algues","10 à 15 cm","Quelques années","Oursin tropical de grande taille.","Observer sans le déplacer.",listOf("sea urchin","urchin")),
A(140,"Holothurie noire","Holothuria mexicana","🪱","Échinodermes","Commun","Fonds sableux et récifs","Détritus organiques","20 à 30 cm","5 à 10 ans","Concombre de mer détritivore important pour les fonds.","Ne pas sortir l'animal de l'eau.",listOf("sea cucumber")),
A(141,"Étoile de mer coussin","Oreaster reticulatus","⭐","Échinodermes","Rare","Fonds sableux et herbiers","Détritus et invertébrés","20 à 30 cm","Plusieurs années","Grande étoile de mer tropicale massive.","Ne jamais la sortir de l'eau.",listOf("cushion star","starfish")),
A(142,"Crevette nettoyeuse","Lysmata amboinensis","🦐","Crustacés","Commun","Récifs et stations de nettoyage","Parasites et débris","4 à 6 cm","1 à 2 ans","Petite crevette rayée vivant sur les récifs.","Observer sans toucher les animaux nettoyés.",listOf("cleaner shrimp","shrimp")),
A(143,"Crabe arlequin","Percnon gibbesi","🦀","Crustacés","Commun","Rochers et récifs","Algues","3 à 5 cm","Quelques années","Petit crabe plat très agile.","Observer dans les interstices rocheux.",listOf("sally lightfoot crab","crab")),
A(144,"Langouste brésilienne","Panulirus guttatus","🦞","Crustacés","Rare","Récifs coralliens","Invertébrés","15 à 25 cm","Plusieurs années","Petite langouste tachetée des récifs.","Observer de nuit sans la capturer.",listOf("spotted spiny lobster","lobster")),
A(145,"Calmar des récifs","Sepioteuthis sepioidea","🦑","Mollusques","Commun","Herbiers et récifs","Poissons et crustacés","15 à 30 cm","1 à 2 ans","Calmar côtier actif en pleine eau.","Observer sans poursuivre les bancs.",listOf("reef squid","squid")),
A(146,"Seiche commune","Sepia officinalis","🦑","Mollusques","Occasionnel","Fonds sableux et herbiers","Crustacés et poissons","15 à 40 cm","1 à 2 ans","Céphalopode capable de changer rapidement de couleur.","Ne pas le toucher.",listOf("cuttlefish","sepia")),
A(147,"Limule américaine","Limulus polyphemus","🦂","Arthropodes","Rare","Fonds sableux et vasières","Vers et petits invertébrés","Jusqu'à 60 cm","20 ans et plus","Arthropode marin ancien à carapace en fer à cheval.","Ne jamais retourner les individus échoués sans précaution.",listOf("horseshoe crab")),
A(148,"Papillon citron","Phoebis sennae","🦋","Papillons","Commun","Jardins et zones ouvertes","Nectar","6 à 7 cm","Quelques semaines","Papillon jaune très mobile.","Observer les floraisons.",listOf("cloudless sulphur","butterfly")),
A(149,"Papillon tigre des Caraïbes","Battus polydamas","🦋","Papillons","Commun","Forêts et jardins","Nectar; plantes hôtes d'aristoloches","8 à 10 cm","Quelques semaines","Grand papillon sombre aux motifs jaunes.","Chercher près des plantes hôtes.",listOf("polydamas swallowtail","swallowtail","butterfly")),
A(150,"Libellule tropicale","Erythemis vesiculosa","🪲","Insectes","Commun","Mares, rivières et zones humides","Insectes","4 à 5 cm","Quelques mois","Libellule tropicale des eaux calmes.","Observer les berges sans piétiner les larves.",listOf("dragonfly","insect"))
)

private fun norm(s: String): String = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
    .replace("\\p{M}+".toRegex(), "")

private val photoCache = mutableMapOf<Int, List<String>>()

private suspend fun commonsImages(a: Animal): List<String> = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
    photoCache[a.id]?.let { return@withContext it }

    fun request(query: String): List<String> {
        return try {
            val q = URLEncoder.encode(query, "UTF-8")
            val api = "https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=$q&gsrnamespace=6&gsrlimit=15&prop=imageinfo&iiprop=url&iiurlwidth=1000&format=json&origin=*"
            val connection = URL(api).openConnection() as HttpURLConnection
            connection.connectTimeout = 10000
            connection.readTimeout = 15000
            connection.setRequestProperty("User-Agent", "Guadadex/5.0 Android wildlife app")
            connection.setRequestProperty("Accept", "application/json")
            val root = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
            val pages = root.optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
            val results = mutableListOf<Pair<Int, String>>()
            val iterator = pages.keys()
            val sci = norm(a.scientific)
            val common = norm(a.name)
            while (iterator.hasNext()) {
                val page = pages.optJSONObject(iterator.next()) ?: continue
                val title = norm(page.optString("title"))
                val info = page.optJSONArray("imageinfo")?.optJSONObject(0) ?: continue
                val url = info.optString("thumburl").ifBlank { info.optString("url") }
                if (url.isBlank()) continue
                var score = 1
                if (title.contains(sci)) score += 100
                if (title.contains(norm(a.scientific.substringBefore(' ')))) score += 30
                if (title.contains(common)) score += 20
                if (title.contains("map") || title.contains("range") || title.contains("distribution")) score -= 20
                results.add(score to url)
            }
            results.sortedByDescending { it.first }.map { it.second }.distinct().take(6)
        } catch (_: Exception) {
            emptyList()
        }
    }

    val result = request(a.scientific).ifEmpty { request(a.name) }
    photoCache[a.id] = result
    result
}

private fun saveObservation(context: Context, uri: Uri, animalId: Int) {
    val prefs = context.getSharedPreferences("guadadex", Context.MODE_PRIVATE)
    val old = prefs.getStringSet("photos_$animalId", emptySet()) ?: emptySet()
    prefs.edit().putStringSet("photos_$animalId", (old + uri.toString()).toSet()).apply()
}

private fun observationUris(context: Context, id: Int): List<String> =
    (context.getSharedPreferences("guadadex", 0).getStringSet("photos_$id", emptySet()) ?: emptySet()).toList()

private fun saveIds(prefs: android.content.SharedPreferences, key: String, ids: Set<Int>) {
    prefs.edit().putStringSet(key, ids.map { it.toString() }.toSet()).apply()
}

@Composable
fun GuadaDexApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("guadadex", Context.MODE_PRIVATE) }
    var seen by remember { mutableStateOf(prefs.getStringSet("seen", emptySet()).mapNotNull { it.toIntOrNull() }.toSet()) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("fav", emptySet()).mapNotNull { it.toIntOrNull() }.toSet()) }
    var tab by remember { mutableStateOf(0) }
    var selected by remember { mutableStateOf<Animal?>(null) }

    val colors = darkColorScheme(
        primary = blue,
        secondary = green,
        background = bg,
        surface = surface,
        onBackground = Color.White,
        onSurface = Color.White
    )

    MaterialTheme(colorScheme = colors) {
        if (selected != null) {
            DetailScreen(
                animal = selected!!,
                isFavorite = favorites.contains(selected!!.id),
                isSeen = seen.contains(selected!!.id),
                onFavorite = {
                    val next = favorites.toMutableSet().apply { if (!add(selected!!.id)) remove(selected!!.id) }
                    favorites = next
                    saveIds(prefs, "fav", next)
                },
                onSeen = {
                    val next = seen.toMutableSet().apply { if (!add(selected!!.id)) remove(selected!!.id) }
                    seen = next
                    saveIds(prefs, "seen", next)
                },
                onBack = { selected = null }
            )
        } else {
            Scaffold(
                containerColor = bg,
                bottomBar = { BottomBar(tab) { tab = it } }
            ) { padding ->
                Box(Modifier.padding(padding).fillMaxSize()) {
                    when (tab) {
                        0 -> HomeScreen(seen.size, onDex = { tab = 1 }, onPhoto = { tab = 2 })
                        1 -> DexScreen(favorites, seen) { selected = it }
                        2 -> PhotoScreen { selected = it }
                        else -> ProfileScreen(favorites, seen) { selected = it }
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomBar(tab: Int, onTab: (Int) -> Unit) {
    NavigationBar(containerColor = Color(0xFF071A23)) {
        val items = listOf(
            "Accueil" to Icons.Default.Home,
            "Espèces" to Icons.Default.MenuBook,
            "Photo" to Icons.Default.PhotoCamera,
            "Profil" to Icons.Default.Person
        )
        items.forEachIndexed { index, item ->
            NavigationBarItem(
                selected = tab == index,
                onClick = { onTab(index) },
                icon = { Icon(item.second, null) },
                label = { Text(item.first) }
            )
        }
    }
}

@Composable
private fun HomeScreen(seen: Int, onDex: () -> Unit, onPhoto: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth().height(230.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0C3342)),
                shape = RoundedCornerShape(28.dp)
            ) {
                Box(Modifier.fillMaxSize().padding(22.dp)) {
                    Column(Modifier.align(Alignment.BottomStart)) {
                        Text("GUADADEX", fontSize = 38.sp, fontWeight = FontWeight.Black, color = yellow)
                        Text("Explorez la faune de Guadeloupe", color = Color.White, fontSize = 16.sp)
                        Text("Découvrez • Photographiez • Apprenez", color = textSoft, fontSize = 12.sp)
                    }
                    Text("🌴", fontSize = 72.sp, modifier = Modifier.align(Alignment.TopEnd))
                }
            }
        }
        item {
            Button(onClick = onDex, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(18.dp)) {
                Icon(Icons.Default.MenuBook, null)
                Spacer(Modifier.width(8.dp))
                Text("Explorer le Guadadex", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
        }
        item {
            Button(
                onClick = onPhoto,
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF147DEB))
            ) {
                Icon(Icons.Default.PhotoCamera, null)
                Spacer(Modifier.width(8.dp))
                Text("Reconnaître une espèce", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = surface), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("Ma progression", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("$seen / ${animals.size} espèces observées", color = textSoft)
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { seen.toFloat() / animals.size.coerceAtLeast(1) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
private fun DexScreen(favorites: Set<Int>, seen: Set<Int>, onSelect: (Animal) -> Unit) {
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Tous") }
    val categories = listOf("Tous", "Mammifères", "Oiseaux", "Reptiles", "Amphibiens", "Tortues marines", "Chauves-souris", "Poissons", "Requins", "Crustacés", "Mollusques", "Papillons", "Échinodermes", "Insectes")
    val normalizedSearch = norm(search.trim())
    val filtered = animals.filter { animal ->
        val matchesCategory = category == "Tous" || animal.category == category
        val matchesSearch = normalizedSearch.isBlank() ||
            norm(animal.name).contains(normalizedSearch) ||
            norm(animal.scientific).contains(normalizedSearch) ||
            animal.aliases.any { norm(it).contains(normalizedSearch) }
        matchesCategory && matchesSearch
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
        Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Espèces", fontSize = 30.sp, fontWeight = FontWeight.Black)
                Text("${filtered.size} résultat(s) • ${animals.size} au total", color = textSoft, fontSize = 12.sp)
            }
            Text("${seen.size}/${animals.size}", color = blue, fontWeight = FontWeight.Bold)
        }
        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            singleLine = true,
            placeholder = { Text("Rechercher une espèce…") },
            leadingIcon = { Icon(Icons.Default.Search, null) },
            trailingIcon = {
                if (search.isNotEmpty()) IconButton({ search = "" }) { Icon(Icons.Default.Clear, "Effacer") }
            },
            shape = RoundedCornerShape(18.dp)
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            categories.forEach { item ->
                FilterChip(selected = category == item, onClick = { category = item }, label = { Text(item) })
            }
        }
        Spacer(Modifier.height(10.dp))
        if (filtered.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = surface), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🔎", fontSize = 44.sp)
                    Text("Aucune espèce trouvée", fontWeight = FontWeight.Bold)
                    Text("Essaie le nom français ou scientifique.", color = textSoft, fontSize = 13.sp)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(filtered, key = { it.id }) { animal ->
                    AnimalRow(animal, favorites.contains(animal.id), seen.contains(animal.id), onSelect)
                }
            }
        }
    }
}

@Composable
private fun AnimalRow(animal: Animal, isFavorite: Boolean, isSeen: Boolean, onClick: (Animal) -> Unit) {
    Card(
        onClick = { onClick(animal) },
        colors = CardDefaults.cardColors(containerColor = surface),
        shape = RoundedCornerShape(18.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(78.dp).background(surface2, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                PhotoThumb(animal)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text("#${animal.id.toString().padStart(3, '0')}", color = blue, fontSize = 11.sp)
                Text(animal.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(animal.scientific, color = textSoft, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(animal.category, color = green, fontSize = 11.sp)
            }
            Column(horizontalAlignment = Alignment.End) {
                if (isFavorite) Text("♥", color = red, fontSize = 22.sp)
                if (isSeen) Text("✓", color = green, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun PhotoThumb(animal: Animal) {
    var url by remember(animal.id) { mutableStateOf<String?>(photoCache[animal.id]?.firstOrNull()) }
    LaunchedEffect(animal.id) { if (url == null) url = commonsImages(animal).firstOrNull() }
    if (url != null) {
        AsyncImage(
            model = url,
            contentDescription = animal.name,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
    } else {
        Text(animal.icon, fontSize = 30.sp)
    }
}

@Composable
private fun DetailScreen(
    animal: Animal,
    isFavorite: Boolean,
    isSeen: Boolean,
    onFavorite: () -> Unit,
    onSeen: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var section by remember { mutableStateOf(0) }
    var examples by remember(animal.id) { mutableStateOf<List<String>>(emptyList()) }
    val observations = observationUris(context, animal.id)
    LaunchedEffect(animal.id) { examples = commonsImages(animal) }

    Column(Modifier.fillMaxSize().background(bg)) {
        Row(Modifier.fillMaxWidth().padding(7.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Retour") }
            Text("#${animal.id.toString().padStart(3, '0')}", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onFavorite) {
                Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "Favori", tint = if (isFavorite) red else Color.White)
            }
        }
        LazyColumn(Modifier.weight(1f)) {
            item {
                if (examples.isNotEmpty()) {
                    AsyncImage(examples.first(), animal.name, Modifier.fillMaxWidth().height(260.dp), contentScale = ContentScale.Crop)
                } else {
                    Box(Modifier.fillMaxWidth().height(260.dp).background(surface), contentAlignment = Alignment.Center) { Text(animal.icon, fontSize = 90.sp) }
                }
            }
            item {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(animal.name, fontSize = 28.sp, fontWeight = FontWeight.Black)
                            Text(animal.scientific, color = textSoft, fontSize = 15.sp)
                        }
                        AssistChip(onClick = {}, label = { Text(animal.rarity) })
                    }
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = onSeen, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
                        Icon(Icons.Default.Visibility, null)
                        Spacer(Modifier.width(7.dp))
                        Text(if (isSeen) "Espèce observée ✓" else "Je l'ai vue")
                    }
                }
            }
            item {
                Row(Modifier.padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    listOf("Aperçu", "Détails", "Galerie").forEachIndexed { index, title ->
                        FilterChip(selected = section == index, onClick = { section = index }, label = { Text(title) })
                    }
                }
            }
            when (section) {
                0 -> item { OverviewSection(animal) }
                1 -> item { DetailSection(animal) }
                2 -> {
                    item { PhotoGallery("Photos d'exemple", examples) }
                    item { ObservationGallery(context, animal.id) }
                }
            }
        }
    }
}

@Composable
private fun OverviewSection(animal: Animal) {
    Section("Informations") {
        InfoRow("📏", "Taille", animal.size)
        InfoRow("🍃", "Régime", animal.diet)
        InfoRow("🌴", "Habitat", animal.habitat)
        InfoRow("⏱️", "Longévité", animal.lifespan)
    }
    Section("Description") { Text(animal.description, color = textSoft, lineHeight = 21.sp) }
}

@Composable
private fun DetailSection(animal: Animal) {
    Section("Fiche de terrain") {
        Text("Habitat", fontWeight = FontWeight.Bold)
        Text(animal.habitat, color = textSoft)
        Spacer(Modifier.height(10.dp))
        Text("Alimentation", fontWeight = FontWeight.Bold)
        Text(animal.diet, color = textSoft)
        Spacer(Modifier.height(10.dp))
        Text("Conseils d'observation", fontWeight = FontWeight.Bold)
        Text(animal.observation, color = textSoft)
    }
    Section("Identification") {
        Text("Nom scientifique", fontWeight = FontWeight.Bold)
        Text(animal.scientific, color = textSoft)
        Spacer(Modifier.height(8.dp))
        Text("Catégorie : ${animal.category}", color = green)
    }
}

@Composable
private fun InfoRow(icon: String, title: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 23.sp, modifier = Modifier.width(40.dp))
        Column {
            Text(title, color = textSoft, fontSize = 12.sp)
            Text(value, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
        colors = CardDefaults.cardColors(containerColor = surface),
        shape = RoundedCornerShape(19.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun PhotoGallery(title: String, urls: List<String>) {
    Section(title) {
        Text("Photos d'exemple • Wikimedia Commons", fontSize = 12.sp, color = textSoft)
        Spacer(Modifier.height(8.dp))
        if (urls.isEmpty()) {
            Text("Recherche des photos en cours ou aucune image disponible.", color = textSoft)
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                items(urls) { url ->
                    AsyncImage(model = url, contentDescription = "Photo d'exemple", modifier = Modifier.width(220.dp).height(170.dp), contentScale = ContentScale.Crop)
                }
            }
        }
    }
}

@Composable
private fun ObservationGallery(context: Context, id: Int) {
    val uris = observationUris(context, id)
    Section("Mes observations") {
        Text("Photos prises ou choisies par toi • séparées des photos d'exemple", fontSize = 12.sp, color = textSoft)
        Spacer(Modifier.height(8.dp))
        if (uris.isEmpty()) {
            Text("Aucune observation enregistrée. Lance une reconnaissance puis associe la photo à cette espèce.", color = textSoft)
        } else {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                items(uris) { uri ->
                    AsyncImage(model = Uri.parse(uri), contentDescription = "Mon observation", modifier = Modifier.width(220.dp).height(170.dp), contentScale = ContentScale.Crop)
                }
            }
        }
    }
}

@Composable
private fun PhotoScreen(onCandidate: (Animal) -> Unit) {
    val context = LocalContext.current
    var result by remember { mutableStateOf("Prends une photo nette de l'animal.") }
    var labels by remember { mutableStateOf<List<String>>(emptyList()) }
    var candidates by remember { mutableStateOf<List<Pair<Animal, Int>>>(emptyList()) }
    var lastUri by remember { mutableStateOf<Uri?>(null) }

    fun categoryFor(label: String): String? {
        val x = norm(label)
        return when {
            listOf("bird", "eagle", "hawk", "owl", "pelican", "heron", "tern", "hummingbird", "kingfisher", "duck", "gull", "warbler").any { x.contains(it) } -> "Oiseaux"
            listOf("iguana", "lizard", "gecko", "snake", "reptile").any { x.contains(it) } -> "Reptiles"
            listOf("frog", "toad", "amphibian").any { x.contains(it) } -> "Amphibiens"
            listOf("turtle", "tortoise").any { x.contains(it) } -> "Tortues marines"
            listOf("dolphin", "whale", "cetacean", "porpoise").any { x.contains(it) } -> "Mammifères marins"
            x.contains("bat") -> "Chauves-souris"
            listOf("butterfly", "moth").any { x.contains(it) } -> "Papillons"
            listOf("crab", "lobster", "shrimp").any { x.contains(it) } -> "Crustacés"
            listOf("octopus", "squid", "cuttlefish", "conch", "mollusk").any { x.contains(it) } -> "Mollusques"
            x.contains("shark") -> "Requins"
            listOf("fish", "ray", "angelfish", "grouper", "snapper", "surgeonfish").any { x.contains(it) } -> "Poissons"
            listOf("urchin", "starfish", "sea cucumber").any { x.contains(it) } -> "Échinodermes"
            listOf("dragonfly", "insect").any { x.contains(it) } -> "Insectes"
            else -> null
        }
    }

    fun score(animal: Animal, detected: List<String>): Int {
        val aliases = (animal.aliases + animal.name + animal.scientific + animal.scientific.substringBefore(' ')).map(::norm)
        var total = 0
        detected.forEach { raw ->
            val label = norm(raw)
            aliases.forEach { alias -> if (alias.length >= 4 && (label.contains(alias) || alias.contains(label))) total += 40 }
            if (categoryFor(label) == animal.category) total += 12
        }
        return total
    }

    fun analyze(bitmap: Bitmap) {
        result = "Analyse en cours…"
        labels = emptyList()
        candidates = emptyList()
        val image = InputImage.fromBitmap(bitmap, 0)
        ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS).process(image)
            .addOnSuccessListener { detected ->
                val names = detected.sortedByDescending { it.confidence }.take(15).map { it.text }
                labels = names
                candidates = animals.map { it to score(it, names) }
                    .filter { it.second > 0 }
                    .sortedByDescending { it.second }
                    .take(5)
                result = if (candidates.isEmpty()) {
                    "Aucune correspondance fiable. Essaie une photo plus nette."
                } else {
                    "${candidates.size} candidat(s) trouvé(s). Vérifie la fiche avant de confirmer."
                }
            }
            .addOnFailureListener { result = "Impossible d'analyser cette image." }
    }

    fun analyzeAndRemember(bitmap: Bitmap) {
        lastUri = bitmapToUri(context, bitmap)
        analyze(bitmap)
    }

    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap -> if (bitmap != null) analyzeAndRemember(bitmap) }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            lastUri = uri
            uriToBitmap(context, uri)?.let { analyze(it) }
        }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) camera.launch(null) }

    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        item {
            Text("Reconnaissance", fontSize = 30.sp, fontWeight = FontWeight.Black)
            Text("Photo → analyse → candidats → fiche", color = textSoft)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = surface), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Button(
                        onClick = {
                            if (androidx.core.content.ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) camera.launch(null)
                            else permission.launch(Manifest.permission.CAMERA)
                        },
                        modifier = Modifier.fillMaxWidth().height(54.dp)
                    ) { Icon(Icons.Default.PhotoCamera, null); Spacer(Modifier.width(8.dp)); Text("Prendre une photo") }
                    OutlinedButton(onClick = { gallery.launch("image/*") }, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                        Icon(Icons.Default.Collections, null); Spacer(Modifier.width(8.dp)); Text("Choisir dans la galerie")
                    }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = surface2), shape = RoundedCornerShape(19.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(result, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    if (labels.isNotEmpty()) {
                        Spacer(Modifier.height(7.dp))
                        Text("Indices visuels : ${labels.joinToString(" • ")}", fontSize = 12.sp, color = textSoft)
                    }
                }
            }
        }
        if (candidates.isNotEmpty()) {
            item { Text("Résultats", fontSize = 21.sp, fontWeight = FontWeight.Bold) }
            items(candidates, key = { it.first.id }) { pair ->
                val animal = pair.first
                val score = pair.second
                Card(
                    onClick = {
                        lastUri?.let { saveObservation(context, it, animal.id) }
                        onCandidate(animal)
                    },
                    colors = CardDefaults.cardColors(containerColor = surface),
                    shape = RoundedCornerShape(17.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(66.dp).background(surface2, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { PhotoThumb(animal) }
                        Spacer(Modifier.width(11.dp))
                        Column(Modifier.weight(1f)) {
                            Text("#${animal.id.toString().padStart(3, '0')}", color = blue, fontSize = 11.sp)
                            Text(animal.name, fontWeight = FontWeight.Bold)
                            Text(animal.scientific, color = textSoft, fontSize = 12.sp)
                        }
                        Text("$score", color = green, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item { Text("La reconnaissance actuelle est une aide à l'identification, pas une preuve scientifique.", fontSize = 12.sp, color = Color.Gray) }
    }
}

@Composable
private fun ProfileScreen(favorites: Set<Int>, seen: Set<Int>, onSelect: (Animal) -> Unit) {
    val context = LocalContext.current
    val photoCount = animals.sumOf { observationUris(context, it.id).size }
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Mon profil", fontSize = 30.sp, fontWeight = FontWeight.Black)
            Text("Ta progression dans le Guadadex", color = textSoft)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = surface), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("${seen.size} / ${animals.size}", fontSize = 34.sp, fontWeight = FontWeight.Black, color = blue)
                    Text("espèces observées")
                    Spacer(Modifier.height(10.dp))
                    LinearProgressIndicator(progress = { seen.size.toFloat() / animals.size.coerceAtLeast(1) }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(12.dp))
                    Text("❤️ ${favorites.size} favoris    📷 $photoCount photos personnelles", color = textSoft)
                }
            }
        }
        item { Text("Mes favoris", fontSize = 21.sp, fontWeight = FontWeight.Bold) }
        items(animals.filter { favorites.contains(it.id) }, key = { it.id }) { animal ->
            AnimalRow(animal, true, seen.contains(animal.id), onSelect)
        }
    }
}

private fun uriToBitmap(context: Context, uri: Uri): Bitmap? = try {
    if (Build.VERSION.SDK_INT >= 28) {
        ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver, uri))
    } else {
        @Suppress("DEPRECATION")
        MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
    }
} catch (_: Exception) { null }

private fun bitmapToUri(context: Context, bitmap: Bitmap): Uri? = try {
    val values = android.content.ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "guadadex_${System.currentTimeMillis()}.jpg")
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.IS_PENDING, 1)
    }
    val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
    context.contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
    if (Build.VERSION.SDK_INT >= 29) {
        val done = android.content.ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
        context.contentResolver.update(uri, done, null, null)
    }
    uri
} catch (_: Exception) { null }
