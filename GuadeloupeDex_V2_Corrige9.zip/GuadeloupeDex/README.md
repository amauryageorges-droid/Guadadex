# GuadeloupeDex V2 corrigée

100 animaux, recherche, filtres, favoris, progression persistante et reconnaissance photo bêta via Google ML Kit.

Compilation fixée sur Java 17 et Kotlin JVM 17. La reconnaissance photo utilise un modèle général et ne garantit pas l'identification exacte d'une espèce.
