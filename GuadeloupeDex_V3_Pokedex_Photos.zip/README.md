# GuadeloupeDex V3

Pokédex de la faune de Guadeloupe. Interface sombre inspirée d'un Pokédex, 100 espèces, recherche, filtres, favoris, espèces vues, fiches détaillées et galeries photo.

Les photos sont chargées à la demande depuis Wikimedia Commons en utilisant le nom scientifique et le nom français de l'espèce.
