package com.example.guadeloupedex

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.graphics.ImageDecoder
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class Animal(val id:Int,val name:String,val scientific:String,val icon:String,val category:String,val rarity:String)

data class AnimalDetails(
    val habitat:String, val diet:String, val size:String, val lifespan:String,
    val description:String, val observation:String
)

val animals=listOf(
    Animal(1, "Raton laveur de Guadeloupe", "Procyon lotor", "🦝", "Mammifères", "Rare"),
    Animal(2, "Iguane des Petites-Antilles", "Iguana delicatissima", "🦎", "Reptiles", "Très rare"),
    Animal(3, "Iguane vert", "Iguana iguana", "🦎", "Reptiles", "Commun"),
    Animal(4, "Anolis de Guadeloupe", "Anolis marmoratus", "🦎", "Reptiles", "Commun"),
    Animal(5, "Mabouya à pattes jaunes", "Hemidactylus mabouia", "🦎", "Reptiles", "Commun"),
    Animal(6, "Técadactyle", "Thecadactylus rapicauda", "🦎", "Reptiles", "Commun"),
    Animal(7, "Typhlops de Guadeloupe", "Typhlops guadeloupensis", "🐍", "Reptiles", "Très rare"),
    Animal(8, "Couresse de Guadeloupe", "Alsophis antillensis", "🐍", "Reptiles", "Très rare"),
    Animal(9, "Couresse des Saintes", "Alsophis sanctonum", "🐍", "Reptiles", "Très rare"),
    Animal(10, "Hylode de Pinchon", "Eleutherodactylus pinchoni", "🐸", "Amphibiens", "Rare"),
    Animal(11, "Hylode de Barlagne", "Eleutherodactylus barlagnei", "🐸", "Amphibiens", "Rare"),
    Animal(12, "Hylode de la Martinique", "Eleutherodactylus martinicensis", "🐸", "Amphibiens", "Commun"),
    Animal(13, "Hylode de Johnstone", "Eleutherodactylus johnstonei", "🐸", "Amphibiens", "Commun"),
    Animal(14, "Tortue verte", "Chelonia mydas", "🐢", "Tortues marines", "Rare"),
    Animal(15, "Tortue imbriquée", "Eretmochelys imbricata", "🐢", "Tortues marines", "Rare"),
    Animal(16, "Tortue luth", "Dermochelys coriacea", "🐢", "Tortues marines", "Très rare"),
    Animal(17, "Tortue caouanne", "Caretta caretta", "🐢", "Tortues marines", "Occasionnel"),
    Animal(18, "Tortue olivâtre", "Lepidochelys olivacea", "🐢", "Tortues marines", "Occasionnel"),
    Animal(19, "Sérotine de Guadeloupe", "Eptesicus guadeloupensis", "🦇", "Chauves-souris", "Très rare"),
    Animal(20, "Fer-de-lance commun", "Artibeus jamaicensis", "🦇", "Chauves-souris", "Commun"),
    Animal(21, "Sturnire de la Guadeloupe", "Sturnira angeli", "🦇", "Chauves-souris", "Rare"),
    Animal(22, "Ardops des Petites-Antilles", "Ardops nichollsi", "🦇", "Chauves-souris", "Rare"),
    Animal(23, "Monophylle des Petites-Antilles", "Monophyllus plethodon", "🦇", "Chauves-souris", "Rare"),
    Animal(24, "Noctilion pêcheur", "Noctilio leporinus", "🦇", "Chauves-souris", "Rare"),
    Animal(25, "Pteronote de Davy", "Pteronotus davyi", "🦇", "Chauves-souris", "Rare"),
    Animal(26, "Molosse commun", "Molossus molossus", "🦇", "Chauves-souris", "Commun"),
    Animal(27, "Tadaride du Brésil", "Tadarida brasiliensis", "🦇", "Chauves-souris", "Commun"),
    Animal(28, "Dauphin tacheté pantropical", "Stenella attenuata", "🐬", "Mammifères marins", "Commun"),
    Animal(29, "Grand dauphin", "Tursiops truncatus", "🐬", "Mammifères marins", "Commun"),
    Animal(30, "Dauphin commun", "Delphinus delphis", "🐬", "Mammifères marins", "Occasionnel"),
    Animal(31, "Dauphin de Fraser", "Lagenodelphis hosei", "🐬", "Mammifères marins", "Rare"),
    Animal(32, "Dauphin à long bec", "Stenella longirostris", "🐬", "Mammifères marins", "Rare"),
    Animal(33, "Dauphin tacheté de l’Atlantique", "Stenella frontalis", "🐬", "Mammifères marins", "Occasionnel"),
    Animal(34, "Globicéphale tropical", "Globicephala macrorhynchus", "🐋", "Mammifères marins", "Commun"),
    Animal(35, "Grand cachalot", "Physeter macrocephalus", "🐋", "Mammifères marins", "Rare"),
    Animal(36, "Cachalot nain", "Kogia sima", "🐋", "Mammifères marins", "Très rare"),
    Animal(37, "Baleine à bosse", "Megaptera novaeangliae", "🐋", "Mammifères marins", "Rare"),
    Animal(38, "Orque naine", "Feresa attenuata", "🐋", "Mammifères marins", "Très rare"),
    Animal(39, "Pseudorque", "Pseudorca crassidens", "🐋", "Mammifères marins", "Très rare"),
    Animal(40, "Pic de Guadeloupe", "Melanerpes herminieri", "🐦", "Oiseaux", "Rare"),
    Animal(41, "Crécerelle d’Amérique", "Falco sparverius", "🦅", "Oiseaux", "Commun"),
    Animal(42, "Frégate superbe", "Fregata magnificens", "🦅", "Oiseaux", "Commun"),
    Animal(43, "Pélican brun", "Pelecanus occidentalis", "🐦", "Oiseaux", "Commun"),
    Animal(44, "Fou brun", "Sula leucogaster", "🐦", "Oiseaux", "Occasionnel"),
    Animal(45, "Paille-en-queue à bec rouge", "Phaethon aethereus", "🐦", "Oiseaux", "Rare"),
    Animal(46, "Héron garde-bœufs", "Bubulcus ibis", "🐦", "Oiseaux", "Commun"),
    Animal(47, "Héron vert", "Butorides virescens", "🐦", "Oiseaux", "Commun"),
    Animal(48, "Grande aigrette", "Ardea alba", "🐦", "Oiseaux", "Commun"),
    Animal(49, "Aigrette neigeuse", "Egretta thula", "🐦", "Oiseaux", "Commun"),
    Animal(50, "Aigrette bleue", "Egretta caerulea", "🐦", "Oiseaux", "Commun"),
    Animal(51, "Paruline jaune", "Setophaga petechia", "🐦", "Oiseaux", "Commun"),
    Animal(52, "Paruline caféiette", "Setophaga plumbea", "🐦", "Oiseaux", "Rare"),
    Animal(53, "Sporophile rouge-gorge", "Loxigilla noctis", "🐦", "Oiseaux", "Commun"),
    Animal(54, "Sucrier à ventre jaune", "Coereba flaveola", "🐦", "Oiseaux", "Très commun"),
    Animal(55, "Trembleur brun", "Cinclocerthia ruficauda", "🐦", "Oiseaux", "Commun"),
    Animal(56, "Merle à lunettes", "Turdus nudigenis", "🐦", "Oiseaux", "Commun"),
    Animal(57, "Quiscale merle", "Quiscalus lugubris", "🐦", "Oiseaux", "Commun"),
    Animal(58, "Moqueur grivotte", "Margarops fuscatus", "🐦", "Oiseaux", "Commun"),
    Animal(59, "Colibri madère", "Eulampis jugularis", "🐦", "Oiseaux", "Commun"),
    Animal(60, "Colibri huppé", "Orthorhyncus cristatus", "🐦", "Oiseaux", "Commun"),
    Animal(61, "Colibri falle-vert", "Eulampis holosericeus", "🐦", "Oiseaux", "Commun"),
    Animal(62, "Tourterelle à queue carrée", "Zenaida aurita", "🐦", "Oiseaux", "Commun"),
    Animal(63, "Tourterelle triste", "Zenaida macroura", "🐦", "Oiseaux", "Commun"),
    Animal(64, "Colombe à queue noire", "Columbina passerina", "🐦", "Oiseaux", "Commun"),
    Animal(65, "Moucherolle gobe-mouches", "Contopus latirostris", "🐦", "Oiseaux", "Rare"),
    Animal(66, "Balbuzard pêcheur", "Pandion haliaetus", "🦅", "Oiseaux", "Occasionnel"),
    Animal(67, "Hirondelle à ventre blanc", "Progne dominicensis", "🐦", "Oiseaux", "Commun"),
    Animal(68, "Martinet ramoneur", "Chaetura pelagica", "🐦", "Oiseaux", "Occasionnel"),
    Animal(69, "Sterne royale", "Thalasseus maximus", "🐦", "Oiseaux", "Commun"),
    Animal(70, "Sterne bridée", "Onychoprion anaethetus", "🐦", "Oiseaux", "Commun"),
    Animal(71, "Noddi brun", "Anous stolidus", "🐦", "Oiseaux", "Commun"),
    Animal(72, "Crabe de terre", "Gecarcinus ruricola", "🦀", "Crustacés", "Commun"),
    Animal(73, "Crabe à barbe", "Ucides cordatus", "🦀", "Crustacés", "Commun"),
    Animal(74, "Crabe de palétuvier", "Aratus pisonii", "🦀", "Crustacés", "Commun"),
    Animal(75, "Petit crabe nageur", "Pachygrapsus gracilis", "🦀", "Crustacés", "Commun"),
    Animal(76, "Crabe sémafot", "Uca rapax", "🦀", "Crustacés", "Commun"),
    Animal(77, "Crabe bleu", "Callinectes sapidus", "🦀", "Crustacés", "Commun"),
    Animal(78, "Langouste des Caraïbes", "Panulirus argus", "🦞", "Crustacés", "Commun"),
    Animal(79, "Cigale de mer", "Scyllarides aequinoctialis", "🦞", "Crustacés", "Rare"),
    Animal(80, "Lambi", "Lobatus gigas", "🐚", "Mollusques", "Rare"),
    Animal(81, "Poulpe commun", "Octopus vulgaris", "🐙", "Mollusques", "Commun"),
    Animal(82, "Mygale de Guadeloupe", "Holothele longipes", "🕷️", "Arachnides", "Rare"),
    Animal(83, "Scorpion des Antilles", "Centruroides sp.", "🦂", "Arachnides", "Rare"),
    Animal(84, "Papillon monarque", "Danaus plexippus", "🦋", "Papillons", "Commun"),
    Animal(85, "Flambeau commun", "Dryas iulia", "🦋", "Papillons", "Commun"),
    Animal(86, "Papillon zèbre", "Heliconius charithonia", "🦋", "Papillons", "Commun"),
    Animal(87, "Papillon tacheté de l’orange", "Anartia jatrophae", "🦋", "Papillons", "Commun"),
    Animal(88, "Papillon queue-de-jonc", "Papilio andraemon", "🦋", "Papillons", "Rare"),
    Animal(89, "Papillon flamboyant", "Heraclides thoas", "🦋", "Papillons", "Commun"),
    Animal(90, "Poisson-papillon rayé", "Chaetodon striatus", "🐠", "Poissons", "Commun"),
    Animal(91, "Poisson-perroquet feu", "Sparisoma viride", "🐠", "Poissons", "Commun"),
    Animal(92, "Poisson-chirurgien bleu", "Acanthurus coeruleus", "🐠", "Poissons", "Commun"),
    Animal(93, "Poisson-chirurgien océanique", "Acanthurus bahianus", "🐠", "Poissons", "Commun"),
    Animal(94, "Pagre jaune", "Lutjanus apodus", "🐠", "Poissons", "Commun"),
    Animal(95, "Serran rayé", "Serranus striatus", "🐠", "Poissons", "Commun"),
    Animal(96, "Barracuda", "Sphyraena barracuda", "🐟", "Poissons", "Commun"),
    Animal(97, "Raie pastenague américaine", "Hypanus americanus", "🐟", "Poissons", "Commun"),
    Animal(98, "Requin nourrice", "Ginglymostoma cirratum", "🦈", "Requins", "Occasionnel"),
    Animal(99, "Requin citron", "Negaprion brevirostris", "🦈", "Requins", "Rare"),
    Animal(100, "Requin-baleine", "Rhincodon typus", "🦈", "Requins", "Très rare")
)

private val bg=Color(0xFF06151D)
private val panel=Color(0xFF102832)
private val panel2=Color(0xFF163642)
private val accent=Color(0xFF29A9FF)
private val green=Color(0xFF35D27A)

fun detailsFor(a:Animal):AnimalDetails {
    val marine=a.category.contains("marins") || a.category in listOf("Poissons","Requins","Crustacés","Mollusques")
    val bird=a.category=="Oiseaux"
    val reptile=a.category in listOf("Reptiles","Tortues marines")
    val habitat=when {
        marine -> "Mer des Caraïbes, récifs, pleine mer et zones côtières"
        bird -> "Forêts, mangroves, zones humides, littoral et jardins"
        reptile -> "Forêts tropicales, zones sèches, falaises et littoral"
        a.category=="Papillons" -> "Jardins, lisières, forêts et zones fleuries"
        a.category=="Chauves-souris" -> "Forêts, grottes, cavités et zones agricoles"
        a.category=="Amphibiens" -> "Forêts humides, ravines et mares"
        else -> "Forêts tropicales, mangroves, littoral et zones rocheuses"
    }
    val diet=when {
        a.category=="Papillons" -> "Nectar, parfois fruits et sève à l'état adulte"
        bird -> "Variable selon l'espèce : fruits, nectar, insectes ou poissons"
        marine -> "Poissons, crustacés, mollusques, algues ou plancton selon l'espèce"
        reptile -> "Variable : végétaux, insectes ou petits animaux"
        a.category=="Chauves-souris" -> "Insectes, fruits ou nectar selon l'espèce"
        a.category=="Amphibiens" -> "Principalement petits invertébrés"
        else -> "Invertébrés et petits animaux selon l'espèce"
    }
    return AnimalDetails(habitat,diet,"Variable selon l'âge et le sexe","Variable selon l'espèce",
        "Espèce répertoriée dans le GuadeloupeDex. Cette fiche rassemble des informations générales pour faciliter l'identification et l'observation sans déranger l'animal.",
        "Observez à distance, sans toucher ni nourrir l'animal. Respectez les espaces protégés et les périodes de reproduction.")
}

suspend fun commonsImages(animal: Animal): List<String> = withContext(Dispatchers.IO) {
    fun load(query: String): List<String> {
        return try {
            val q = URLEncoder.encode(query, "UTF-8")
            val api = "https://commons.wikimedia.org/w/api.php" +
                "?action=query&generator=search&gsrsearch=$q&gsrnamespace=6&gsrlimit=12" +
                "&prop=imageinfo&iiprop=url&iiurlwidth=1200&format=json&origin=*"
            val c = URL(api).openConnection() as HttpURLConnection
            c.connectTimeout = 10000
            c.readTimeout = 15000
            c.requestMethod = "GET"
            val text = c.inputStream.bufferedReader().use { it.readText() }
            val pages = JSONObject(text).optJSONObject("query")?.optJSONObject("pages") ?: return emptyList()
            val scientific = animal.scientific.lowercase()
            val genus = scientific.substringBefore(" ")
            val common = animal.name.lowercase()
            val out = mutableListOf<String>()
            val keys = pages.keys()
            while (keys.hasNext()) {
                val page = pages.optJSONObject(keys.next()) ?: continue
                val title = page.optString("title").lowercase()
                val titleClean = title.replace("file:", "").replace('_', ' ')
                val relevant = titleClean.contains(scientific) ||
                    (titleClean.contains(genus) && titleClean.contains(common.substringBefore(" ")))
                if (!relevant) continue
                val info = page.optJSONArray("imageinfo")?.optJSONObject(0) ?: continue
                val imageUrl = info.optString("thumburl").ifBlank { info.optString("url") }
                if (imageUrl.isNotBlank()) out.add(imageUrl)
            }
            out.distinct()
        } catch (_: Exception) {
            emptyList()
        }
    }

    // Recherche stricte sur le nom scientifique pour éviter qu'une espèce
    // récupère les photos d'une autre espèce.
    val strict = load("\"${animal.scientific}\"")
    if (strict.isNotEmpty()) strict else load(animal.scientific)
}

@Composable
fun RemotePhotos(animal: Animal, height: Int = 210, gallery: Boolean = false) {
    var urls by remember(animal.id) { mutableStateOf<List<String>>(emptyList()) }
    var loading by remember(animal.id) { mutableStateOf(true) }

    LaunchedEffect(animal.id) {
        loading = true
        urls = commonsImages(animal)
        loading = false
    }

    if (gallery) {
        if (loading) {
            Box(
                Modifier.fillMaxWidth().height(height.dp).background(panel, RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) { Text("Recherche des photos de ${animal.scientific}…", color = Color.LightGray) }
        } else if (urls.isEmpty()) {
            Box(
                Modifier.fillMaxWidth().height(height.dp).background(panel, RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(animal.icon, fontSize = 52.sp)
                    Text("Aucune photo fiable trouvée", color = Color.LightGray)
                    Text("pour cette espèce", fontSize = 12.sp, color = Color.Gray)
                }
            }
        } else {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(horizontal = 2.dp)
            ) {
                items(urls) { url ->
                    AsyncImage(
                        model = url,
                        contentDescription = animal.name,
                        modifier = Modifier.width(220.dp).height(height.dp),
                        contentScale = ContentScale.Crop
                    )
                }
            }
        }
    } else {
        if (urls.isNotEmpty()) {
            AsyncImage(
                model = urls.first(),
                contentDescription = animal.name,
                modifier = Modifier.fillMaxWidth().height(height.dp),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(
                Modifier.fillMaxWidth().height(height.dp).background(panel, RoundedCornerShape(18.dp)),
                contentAlignment = Alignment.Center
            ) { Text(animal.icon, fontSize = 70.sp) }
        }
    }
}

fun normalizeText(value: String): String =
    java.text.Normalizer.normalize(value.lowercase(), java.text.Normalizer.Form.NFD)
        .replace("\\p{InCombiningDiacriticalMarks}+".toRegex(), "")
        .replace("’", "'")

fun aliasesFor(animal: Animal): List<String> {
    val common = normalizeText(animal.name)
    val scientific = normalizeText(animal.scientific)
    val firstScientific = scientific.substringBefore(" ")
    return listOf(common, scientific, firstScientific).distinct()
}

fun findExactCandidates(labels: List<String>): List<Animal> {
    val normalizedLabels = labels.map { normalizeText(it) }
    val scored = animals.map { animal ->
        var score = 0
        val aliases = aliasesFor(animal)
        for (label in normalizedLabels) {
            for (alias in aliases) {
                if (alias.length >= 5 && (label.contains(alias) || alias.contains(label))) score += 10
            }
        }
        animal to score
    }.filter { it.second > 0 }
        .sortedByDescending { it.second }
    val best = scored.firstOrNull()?.second ?: 0
    return scored.filter { it.second == best && best > 0 }.take(6).map { it.first }
}

fun probableCategory(labels: List<String>): String? {
    val text = labels.joinToString(" ").lowercase()
    return when {
        listOf("bird", "avian", "eagle", "hawk", "owl", "parrot", "pelican", "heron", "hummingbird", "tern").any(text::contains) -> "Oiseaux"
        listOf("iguana", "lizard", "gecko", "snake", "reptile").any(text::contains) -> "Reptiles"
        listOf("frog", "toad", "amphibian").any(text::contains) -> "Amphibiens"
        listOf("turtle", "tortoise", "sea turtle").any(text::contains) -> "Tortues marines"
        listOf("dolphin", "whale", "porpoise", "cetacean").any(text::contains) -> "Mammifères marins"
        listOf("bat", "flying fox").any(text::contains) -> "Chauves-souris"
        listOf("butterfly", "moth").any(text::contains) -> "Papillons"
        listOf("crab", "lobster", "crustacean").any(text::contains) -> "Crustacés"
        listOf("octopus", "mollusk", "snail", "conch").any(text::contains) -> "Mollusques"
        listOf("shark", "ray", "fish").any(text::contains) -> "Poissons"
        else -> null
    }
}

fun shareImage(context: Context, uri: Uri) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "image/*"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "Identifier cette photo avec…"))
}

fun bitmapToMediaUri(context: Context, bitmap: Bitmap): Uri? {
    return try {
        val values = android.content.ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "guadeloupedex_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            if (android.os.Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        context.contentResolver.openOutputStream(uri)?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            context.contentResolver.update(uri, values, null, null)
        }
        uri
    } catch (_: Exception) { null }
}

@Composable
fun App(){
    val context=LocalContext.current
    val prefs=remember{context.getSharedPreferences("dex",Context.MODE_PRIVATE)}
    var seen by remember{mutableStateOf(prefs.getStringSet("seen",emptySet())!!.mapNotNull{it.toIntOrNull()}.toSet())}
    var fav by remember{mutableStateOf(prefs.getStringSet("fav",emptySet())!!.mapNotNull{it.toIntOrNull()}.toSet())}
    var tab by remember{mutableStateOf(0)}
    var selected by remember{mutableStateOf<Animal?>(null)}
    MaterialTheme(colorScheme=darkColorScheme(primary=accent,background=bg,surface=panel)) {
        if(selected!=null){
            DetailScreen(selected!!, fav.contains(selected!!.id), seen.contains(selected!!.id), {id->
                val n=fav.toMutableSet(); if(!n.add(id)) n.remove(id); fav=n; prefs.edit().putStringSet("fav",n.map{it.toString()}.toSet()).apply()
            }, {id->
                val n=seen.toMutableSet(); if(!n.add(id)) n.remove(id); seen=n; prefs.edit().putStringSet("seen",n.map{it.toString()}.toSet()).apply()
            }){selected=null}
        } else Scaffold(containerColor=bg,bottomBar={NavigationBar(containerColor=Color(0xFF081A23)){
            val nav=listOf("Accueil" to Icons.Default.Home,"Pokédex" to Icons.Default.CatchingPokemon,"Photo" to Icons.Default.PhotoCamera,"Favoris" to Icons.Default.Favorite)
            nav.forEachIndexed{i,p->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(p.second,null)},label={Text(p.first)})}
        }}){pad->Box(Modifier.padding(pad)){when(tab){0->HomeScreen(seen.size){tab=1};1->DexScreen(fav,seen){selected=it};2->PhotoScreen{a->selected=a};3->FavoritesScreen(fav,seen){selected=it}}}}
    }
}

@Composable
fun HomeScreen(count:Int,onDex:()->Unit){
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        item{Text("GuadeloupeDex",fontSize=32.sp,fontWeight=FontWeight.Black);Text("Le Pokédex de la faune de Guadeloupe",color=Color.LightGray)}
        item{Card(colors=CardDefaults.cardColors(containerColor=panel),shape=RoundedCornerShape(22.dp)){Column(Modifier.padding(20.dp)){Text("PROGRESSION",color=accent,fontWeight=FontWeight.Bold);Text("$count / 100 espèces observées",fontSize=24.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp));LinearProgressIndicator(progress={count/100f},modifier=Modifier.fillMaxWidth())}}}
        item{Button(onClick=onDex,modifier=Modifier.fillMaxWidth().height(56.dp),shape=RoundedCornerShape(18.dp)){Icon(Icons.Default.MenuBook,null);Spacer(Modifier.width(8.dp));Text("Explorer le Pokédex")}}
        item{Text("Au programme",fontSize=22.sp,fontWeight=FontWeight.Bold)}
        item{Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){InfoTile("📸","Photos","Galeries par espèce",Modifier.weight(1f));InfoTile("🗺️","Habitats","Mer, forêt, littoral",Modifier.weight(1f))}}
        item{Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){InfoTile("❤️","Favoris","Tes espèces",Modifier.weight(1f));InfoTile("🔎","Recherche","Nom ou catégorie",Modifier.weight(1f))}}
    }
}

@Composable fun InfoTile(icon:String,title:String,sub:String,modifier:Modifier){Card(modifier,colors=CardDefaults.cardColors(containerColor=panel),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(14.dp)){Text(icon,fontSize=28.sp);Text(title,fontWeight=FontWeight.Bold);Text(sub,color=Color.LightGray,fontSize=12.sp)}}}

@Composable
fun DexScreen(fav:Set<Int>,seen:Set<Int>,onSelect:(Animal)->Unit){
    var search by remember{mutableStateOf("")}; var cat by remember{mutableStateOf("Tous")}
    val cats=listOf("Tous","Mammifères","Oiseaux","Reptiles","Amphibiens","Tortues marines","Poissons","Crustacés","Mollusques","Papillons","Chauves-souris","Requins")
    val filtered=animals.filter{(cat=="Tous"||it.category==cat)&&(search.isBlank()||it.name.contains(search,true)||it.scientific.contains(search,true))}
    Column(Modifier.fillMaxSize().padding(horizontal=12.dp)){
        Row(Modifier.fillMaxWidth().padding(top=10.dp),verticalAlignment=Alignment.CenterVertically){Text("Pokédex",fontSize=30.sp,fontWeight=FontWeight.Black);Spacer(Modifier.weight(1f));Text("${seen.size}/100",color=accent,fontWeight=FontWeight.Bold)}
        OutlinedTextField(value=search,onValueChange={search=it},modifier=Modifier.fillMaxWidth().padding(vertical=8.dp),singleLine=true,placeholder={Text("Rechercher une espèce…")},leadingIcon={Icon(Icons.Default.Search,null)})
        Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){cats.forEach{c->FilterChip(selected=cat==c,onClick={cat=c},label={Text(c)})}}
        Spacer(Modifier.height(8.dp))
        LazyVerticalGrid(columns=GridCells.Fixed(2),contentPadding=PaddingValues(bottom=18.dp),horizontalArrangement=Arrangement.spacedBy(8.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(filtered,key={it.id}){a->AnimalCard(a,fav.contains(a.id),seen.contains(a.id),onSelect)}}
    }
}

@Composable
fun AnimalCard(a:Animal,isFav:Boolean,isSeen:Boolean,onSelect:(Animal)->Unit){Card(onClick={onSelect(a)},colors=CardDefaults.cardColors(containerColor=panel),shape=RoundedCornerShape(16.dp)){Column{RemotePhotos(a,125);Column(Modifier.padding(10.dp)){Row{Text("#${a.id.toString().padStart(3,'0')}",color=accent,fontSize=12.sp);Spacer(Modifier.weight(1f));if(isFav)Icon(Icons.Default.Favorite,null,tint=Color.Red,modifier=Modifier.size(16.dp))};Text(a.name,fontWeight=FontWeight.Bold,maxLines=2,overflow=TextOverflow.Ellipsis);Text(a.scientific,fontSize=11.sp,color=Color.LightGray,maxLines=1,overflow=TextOverflow.Ellipsis);Row{Text(a.category,fontSize=10.sp,color=Color.LightGray);Spacer(Modifier.weight(1f));if(isSeen)Text("✓ Vu",fontSize=10.sp,color=green,fontWeight=FontWeight.Bold)}}}}}

@Composable
fun DetailScreen(
    a: Animal,
    isFav: Boolean,
    isSeen: Boolean,
    toggleFav: (Int) -> Unit,
    toggleSeen: (Int) -> Unit,
    onBack: () -> Unit
) {
    val d = detailsFor(a)
    LazyColumn(Modifier.fillMaxSize().background(bg)) {
        item {
            Row(
                Modifier.fillMaxWidth().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Retour") }
                Text("#${a.id.toString().padStart(3, '0')}", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { toggleFav(a.id) }) {
                    Icon(
                        if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        "Favori",
                        tint = if (isFav) Color.Red else Color.White
                    )
                }
            }
        }
        item { RemotePhotos(a, 250) }
        item {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(a.name, fontSize = 27.sp, fontWeight = FontWeight.Black)
                        Text(a.scientific, fontSize = 16.sp, color = Color.LightGray)
                    }
                    Surface(color = Color(0xFF183B2A), shape = RoundedCornerShape(50)) {
                        Text(a.rarity, Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = green, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }
        item {
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { toggleSeen(a.id) }, modifier = Modifier.weight(1f)) {
                    Icon(if (isSeen) Icons.Default.Visibility else Icons.Default.VisibilityOff, null)
                    Spacer(Modifier.width(5.dp))
                    Text(if (isSeen) "Je l'ai vu" else "Marquer vu")
                }
                OutlinedButton(onClick = { toggleFav(a.id) }, modifier = Modifier.weight(1f)) {
                    Text(if (isFav) "Retirer favori" else "Ajouter favori")
                }
            }
        }
        item { Section("Fiche d'identité") { StatGrid(d) } }
        item { Section("Description") { Text(d.description, color = Color(0xFFE1EAED), lineHeight = 22.sp) } }
        item {
            Section("Habitat et observation") {
                Text("Habitat", fontWeight = FontWeight.Bold, color = accent)
                Text(d.habitat, color = Color.LightGray)
                Spacer(Modifier.height(10.dp))
                Text("Conseil", fontWeight = FontWeight.Bold, color = accent)
                Text(d.observation, color = Color.LightGray)
            }
        }
        item {
            Section("Galerie photo") {
                Text("Photos Wikimedia Commons liées à l'espèce.", fontSize = 12.sp, color = Color.Gray)
                Spacer(Modifier.height(8.dp))
                RemotePhotos(a, 170, true)
            }
        }
        item { Spacer(Modifier.height(30.dp)) }
    }
}

@Composable
fun Section(title: String, content: @Composable () -> Unit) {Card(Modifier.padding(horizontal=16.dp,vertical=7.dp),colors=CardDefaults.cardColors(containerColor=panel),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Text(title,fontSize=19.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp));content()}}}
@Composable fun StatGrid(d:AnimalDetails){Column(verticalArrangement=Arrangement.spacedBy(10.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("Habitat",d.habitat,Modifier.weight(1f));Stat("Régime",d.diet,Modifier.weight(1f))};Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){Stat("Taille",d.size,Modifier.weight(1f));Stat("Longévité",d.lifespan,Modifier.weight(1f))}}}
@Composable fun Stat(label:String,value:String,modifier:Modifier){Column(modifier.background(panel2,RoundedCornerShape(12.dp)).padding(10.dp)){Text(label,fontSize=11.sp,color=accent);Text(value,fontSize=12.sp,color=Color.White)}}

@Composable
fun PhotoScreen(onCandidate: (Animal) -> Unit) {
    val context = LocalContext.current
    var result by remember { mutableStateOf("Prends une photo ou choisis-en une dans la galerie.") }
    var labels by remember { mutableStateOf<List<String>>(emptyList()) }
    var confidence by remember { mutableStateOf<Float?>(null) }
    var candidates by remember { mutableStateOf<List<Animal>>(emptyList()) }
    var category by remember { mutableStateOf<String?>(null) }
    var shareUri by remember { mutableStateOf<Uri?>(null) }

    fun analyze(bitmap: Bitmap) {
        result = "Analyse de l'image…"
        labels = emptyList()
        confidence = null
        candidates = emptyList()
        category = null
        val image = InputImage.fromBitmap(bitmap, 0)
        ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS).process(image)
            .addOnSuccessListener { detected ->
                val top = detected.sortedByDescending { it.confidence }.take(8)
                labels = top.map { it.text }
                confidence = top.firstOrNull()?.confidence
                val exact = findExactCandidates(labels)
                if (exact.isNotEmpty()) {
                    candidates = exact
                    result = if (exact.size == 1) {
                        "Espèce potentiellement reconnue : ${exact.first().name}"
                    } else {
                        "Plusieurs espèces correspondent aux indices de la photo. Choisis la bonne fiche :"
                    }
                } else {
                    category = probableCategory(labels)
                    candidates = category?.let { cat -> animals.filter { it.category == cat }.take(12) } ?: emptyList()
                    result = if (category != null) {
                        "Je reconnais surtout la catégorie « $category ». Je ne vais pas inventer une espèce : choisis la fiche qui correspond."
                    } else {
                        "Je n'ai pas assez d'indices pour identifier une espèce avec certitude."
                    }
                }
            }
            .addOnFailureListener {
                result = "Impossible d'analyser cette image."
            }
    }

    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap ->
        if (bitmap != null) {
            shareUri = bitmapToMediaUri(context, bitmap)
            analyze(bitmap)
        }
    }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            shareUri = uri
            val bitmap = mainImageBitmap(context, uri)
            if (bitmap != null) analyze(bitmap) else result = "Impossible de lire cette image."
        }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) camera.launch(null) else result = "Autorisation caméra refusée."
    }

    LazyColumn(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("🔎 Reconnaissance photo", fontSize = 30.sp, fontWeight = FontWeight.Black)
            Text(
                "L'ancien système ouvrait automatiquement le premier oiseau trouvé — c'est corrigé. L'application ne choisit plus une espèce au hasard.",
                color = Color.LightGray
            )
        }
        item {
            Button(
                onClick = {
                    if (androidx.core.content.ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
                        camera.launch(null)
                    } else permission.launch(Manifest.permission.CAMERA)
                },
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                Icon(Icons.Default.PhotoCamera, null)
                Spacer(Modifier.width(8.dp))
                Text("Prendre une photo")
            }
            OutlinedButton(
                onClick = { gallery.launch("image/*") },
                modifier = Modifier.fillMaxWidth().height(54.dp)
            ) {
                Icon(Icons.Default.Collections, null)
                Spacer(Modifier.width(8.dp))
                Text("Choisir une photo")
            }
        }
        shareUri?.let { uri ->
            item {
                OutlinedButton(onClick = { shareImage(context, uri) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Share, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Essayer une reconnaissance externe (Google Lens, etc.)")
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text(result, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    confidence?.let { Text("Indice ML Kit : ${(it * 100).toInt()} %", color = accent) }
                    if (labels.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("Indices détectés :", fontWeight = FontWeight.Bold)
                        Text(labels.joinToString(" • "), color = Color.LightGray, fontSize = 13.sp)
                    }
                }
            }
        }
        if (candidates.isNotEmpty()) {
            item { Text("Espèces candidates", fontSize = 21.sp, fontWeight = FontWeight.Bold) }
            items(candidates, key = { it.id }) { animal ->
                Card(
                    onClick = { onCandidate(animal) },
                    colors = CardDefaults.cardColors(containerColor = panel),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(animal.icon, fontSize = 34.sp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("#${animal.id.toString().padStart(3, '0')}  ${animal.name}", fontWeight = FontWeight.Bold)
                            Text(animal.scientific, color = Color.LightGray, fontSize = 12.sp)
                        }
                        Icon(Icons.Default.ChevronRight, null)
                    }
                }
            }
        }
        item {
            Text(
                "⚠️ Pour une identification réellement au niveau de l'espèce, il faut un modèle spécialisé entraîné sur ces espèces. ML Kit seul est un modèle généraliste ; cette version ne prétend donc plus reconnaître une espèce qu'il ne connaît pas.",
                color = Color.Gray,
                fontSize = 12.sp
            )
        }
    }
}

@Composable fun FavoritesScreen(fav:Set<Int>,seen:Set<Int>,onSelect:(Animal)->Unit){val list=animals.filter{fav.contains(it.id)};LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){item{Text("Mes favoris",fontSize=30.sp,fontWeight=FontWeight.Black);Text("${list.size} espèce(s)",color=Color.LightGray)};items(list){a->Row(Modifier.fillMaxWidth().background(panel,RoundedCornerShape(16.dp)).padding(8.dp),verticalAlignment=Alignment.CenterVertically){RemotePhotos(a,80);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(a.name,fontWeight=FontWeight.Bold);Text(a.scientific,fontSize=12.sp,color=Color.Gray);if(seen.contains(a.id))Text("✓ Déjà observé",fontSize=11.sp,color=green)};IconButton(onClick={onSelect(a)}){Icon(Icons.Default.ChevronRight,null)}}}}}

fun mainImageBitmap(context:Context,uri:Uri):Bitmap?=try{if(android.os.Build.VERSION.SDK_INT>=28)ImageDecoder.decodeBitmap(ImageDecoder.createSource(context.contentResolver,uri)) else @Suppress("DEPRECATION") MediaStore.Images.Media.getBitmap(context.contentResolver,uri)}catch(_:Exception){null}

class MainActivity:androidx.activity.ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{App()}}}
